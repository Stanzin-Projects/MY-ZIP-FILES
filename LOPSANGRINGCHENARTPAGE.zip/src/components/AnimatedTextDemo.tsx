import { AnimatedTextCaption } from './AnimatedTextCaption';

export function AnimatedTextDemo() {
  return (
    <div className="min-h-screen bg-background p-8 space-y-16">
      <div className="max-w-4xl mx-auto space-y-16">
        {/* Header */}
        <div className="text-center space-y-4">
          <h1 className="text-4xl font-medium">AnimatedTextCaption Demo</h1>
          <p className="text-muted-foreground">
            Smooth text animation component with customizable transitions
          </p>
        </div>

        {/* Default Art & Sketching Captions */}
        <section className="space-y-6">
          <h2 className="text-2xl font-medium">Default Art & Sketching Captions</h2>
          <div className="bg-card p-8 rounded-lg border">
            <AnimatedTextCaption />
          </div>
          <div className="text-sm text-muted-foreground">
            <p><strong>Default captions:</strong></p>
            <ul className="mt-2 space-y-1">
              <li>• "Bringing Imagination to Paper"</li>
              <li>• "Lines That Speak Stories"</li>
              <li>• "Every Sketch Has a Soul"</li>
              <li>• "Art in Every Stroke"</li>
              <li>• "Shadows and Light in Harmony"</li>
            </ul>
          </div>
        </section>

        {/* Custom Captions Example */}
        <section className="space-y-6">
          <h2 className="text-2xl font-medium">Custom Captions - Gallery Focus</h2>
          <div className="bg-card p-8 rounded-lg border">
            <AnimatedTextCaption 
              customCaptions={[
                "Discover Unique Artworks",
                "Transform Your Space",
                "Art That Inspires",
                "Original Paintings & Prints",
                "Your Story, Our Canvas"
              ]}
              animationDuration={3500}
            />
          </div>
        </section>

        {/* Different Text Sizes */}
        <section className="space-y-6">
          <h2 className="text-2xl font-medium">Different Text Sizes</h2>
          
          <div className="space-y-8">
            <div className="bg-card p-6 rounded-lg border">
              <h3 className="text-lg font-medium mb-4">Large Hero Size</h3>
              <AnimatedTextCaption 
                textSize="text-3xl sm:text-4xl md:text-5xl"
                customCaptions={["Large Hero Text", "Impactful Headlines", "Bold Statements"]}
                animationDuration={3000}
              />
            </div>

            <div className="bg-card p-6 rounded-lg border">
              <h3 className="text-lg font-medium mb-4">Medium Section Title</h3>
              <AnimatedTextCaption 
                textSize="text-xl sm:text-2xl md:text-3xl"
                customCaptions={["Medium Section Text", "Perfect for Subtitles", "Balanced Typography"]}
                animationDuration={3000}
              />
            </div>

            <div className="bg-card p-6 rounded-lg border">
              <h3 className="text-lg font-medium mb-4">Small Body Text</h3>
              <AnimatedTextCaption 
                textSize="text-base sm:text-lg"
                customCaptions={["Small body text", "Subtle animations", "Supporting content"]}
                animationDuration={3000}
                className="text-muted-foreground"
              />
            </div>
          </div>
        </section>

        {/* Fast Animation Example */}
        <section className="space-y-6">
          <h2 className="text-2xl font-medium">Fast Animation (2 seconds)</h2>
          <div className="bg-card p-8 rounded-lg border">
            <AnimatedTextCaption 
              customCaptions={[
                "Quick Transitions",
                "Fast Paced",
                "Dynamic Changes",
                "Rapid Updates",
                "Speedy Animation"
              ]}
              animationDuration={2000}
              textSize="text-2xl sm:text-3xl"
            />
          </div>
        </section>

        {/* Slow Animation Example */}
        <section className="space-y-6">
          <h2 className="text-2xl font-medium">Slow Animation (6 seconds)</h2>
          <div className="bg-card p-8 rounded-lg border">
            <AnimatedTextCaption 
              customCaptions={[
                "Contemplative Pace",
                "Thoughtful Transitions",
                "Patient Animation",
                "Deliberate Changes",
                "Mindful Movement"
              ]}
              animationDuration={6000}
              textSize="text-2xl sm:text-3xl"
            />
          </div>
        </section>

        {/* Usage Instructions */}
        <section className="space-y-6">
          <h2 className="text-2xl font-medium">Usage Instructions</h2>
          <div className="bg-muted/30 p-6 rounded-lg space-y-4">
            <h3 className="text-lg font-medium">Props</h3>
            <ul className="space-y-2 text-sm">
              <li><strong>className:</strong> Additional CSS classes for the container</li>
              <li><strong>textSize:</strong> Tailwind text size classes (default: large hero size)</li>
              <li><strong>animationDuration:</strong> Time in milliseconds between transitions (default: 4000)</li>
              <li><strong>customCaptions:</strong> Array of custom text strings to cycle through</li>
            </ul>
            
            <h3 className="text-lg font-medium mt-6">Example Code</h3>
            <pre className="bg-background p-4 rounded text-xs overflow-x-auto">
{`<AnimatedTextCaption 
  customCaptions={[
    "Your Custom Text",
    "Another Caption",
    "Third Option"
  ]}
  textSize="text-2xl sm:text-3xl"
  animationDuration={3000}
  className="text-center"
/>`}
            </pre>
          </div>
        </section>
      </div>
    </div>
  );
}