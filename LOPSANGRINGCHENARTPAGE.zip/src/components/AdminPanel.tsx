import { useState } from 'react';
import { motion } from 'motion/react';
import { Edit, Plus, Save, X, Eye, EyeOff, Trash2, Percent, LogOut, Settings, Palette } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Label } from './ui/label';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { ContentManagement, type SiteContent } from './ContentManagement';
import { toast } from 'sonner@2.0.3';
import type { Artwork } from './ArtGallery';

interface AdminPanelProps {
  isOpen: boolean;
  onClose: () => void;
  artworks: Artwork[];
  onUpdateArtwork: (artwork: Artwork) => void;
  onAddArtwork: (artwork: Omit<Artwork, 'id'>) => void;
  onDeleteArtwork: (id: string) => void;
  onLogout: () => void;
  siteContent: SiteContent;
  onUpdateSiteContent: (content: SiteContent) => void;
}

export function AdminPanel({
  isOpen,
  onClose,
  artworks,
  onUpdateArtwork,
  onAddArtwork,
  onDeleteArtwork,
  onLogout,
  siteContent,
  onUpdateSiteContent,
}: AdminPanelProps) {
  const [editingArtwork, setEditingArtwork] = useState<Artwork | null>(null);
  const [showAddForm, setShowAddForm] = useState(false);
  const [activeTab, setActiveTab] = useState('artworks');
  const [newArtwork, setNewArtwork] = useState({
    title: '',
    price: '',
    originalPrice: '',
    discount: '',
    description: '',
    image: '',
    category: '',
    dimensions: '',
    medium: '',
  });

  const handleSaveArtwork = (artwork: Artwork) => {
    onUpdateArtwork(artwork);
    setEditingArtwork(null);
    toast.success('Artwork updated successfully');
  };

  const handleAddArtwork = () => {
    if (!newArtwork.title || !newArtwork.price || !newArtwork.image) {
      toast.error('Please fill in all required fields');
      return;
    }

    const artwork: Omit<Artwork, 'id'> = {
      title: newArtwork.title,
      price: parseFloat(newArtwork.price),
      originalPrice: newArtwork.originalPrice ? parseFloat(newArtwork.originalPrice) : undefined,
      discount: newArtwork.discount ? parseInt(newArtwork.discount) : undefined,
      description: newArtwork.description,
      image: newArtwork.image,
      category: newArtwork.category,
      dimensions: newArtwork.dimensions,
      medium: newArtwork.medium,
    };

    onAddArtwork(artwork);
    setNewArtwork({
      title: '',
      price: '',
      originalPrice: '',
      discount: '',
      description: '',
      image: '',
      category: '',
      dimensions: '',
      medium: '',
    });
    setShowAddForm(false);
    toast.success('New artwork added successfully');
  };

  const handleLogout = () => {
    onLogout();
    onClose();
    toast.success('Logged out successfully');
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-7xl max-h-[95vh] overflow-y-auto">
        <DialogHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
          <DialogTitle className="flex items-center gap-2">
            <Settings className="h-5 w-5" />
            Admin Dashboard
          </DialogTitle>
          <div className="flex items-center gap-2">
            <Badge variant="secondary">Admin Mode</Badge>
            <Button
              variant="outline"
              size="sm"
              onClick={handleLogout}
              className="flex items-center gap-2"
            >
              <LogOut className="h-4 w-4" />
              Logout
            </Button>
          </div>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="artworks" className="flex items-center gap-2">
              <Palette className="h-4 w-4" />
              Artwork Management
            </TabsTrigger>
            <TabsTrigger value="content" className="flex items-center gap-2">
              <Edit className="h-4 w-4" />
              Content Management
            </TabsTrigger>
          </TabsList>

          {/* Artwork Management Tab */}
          <TabsContent value="artworks" className="space-y-6">
            {/* Add New Artwork */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  Add New Artwork
                  <Button
                    variant="outline"
                    onClick={() => setShowAddForm(!showAddForm)}
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    {showAddForm ? 'Cancel' : 'Add Artwork'}
                  </Button>
                </CardTitle>
              </CardHeader>
              {showAddForm && (
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="title">Title *</Label>
                      <Input
                        id="title"
                        value={newArtwork.title}
                        onChange={(e) => setNewArtwork({ ...newArtwork, title: e.target.value })}
                        placeholder="Artwork title"
                      />
                    </div>
                    <div>
                      <Label htmlFor="category">Category</Label>
                      <Input
                        id="category"
                        value={newArtwork.category}
                        onChange={(e) => setNewArtwork({ ...newArtwork, category: e.target.value })}
                        placeholder="e.g., Abstract, Portrait"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-4">
                    <div>
                      <Label htmlFor="price">Price *</Label>
                      <Input
                        id="price"
                        type="number"
                        value={newArtwork.price}
                        onChange={(e) => setNewArtwork({ ...newArtwork, price: e.target.value })}
                        placeholder="299"
                      />
                    </div>
                    <div>
                      <Label htmlFor="originalPrice">Original Price</Label>
                      <Input
                        id="originalPrice"
                        type="number"
                        value={newArtwork.originalPrice}
                        onChange={(e) => setNewArtwork({ ...newArtwork, originalPrice: e.target.value })}
                        placeholder="399"
                      />
                    </div>
                    <div>
                      <Label htmlFor="discount">Discount %</Label>
                      <Input
                        id="discount"
                        type="number"
                        value={newArtwork.discount}
                        onChange={(e) => setNewArtwork({ ...newArtwork, discount: e.target.value })}
                        placeholder="25"
                      />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="image">Image URL *</Label>
                    <Input
                      id="image"
                      value={newArtwork.image}
                      onChange={(e) => setNewArtwork({ ...newArtwork, image: e.target.value })}
                      placeholder="https://..."
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="dimensions">Dimensions</Label>
                      <Input
                        id="dimensions"
                        value={newArtwork.dimensions}
                        onChange={(e) => setNewArtwork({ ...newArtwork, dimensions: e.target.value })}
                        placeholder="24 x 36 inches"
                      />
                    </div>
                    <div>
                      <Label htmlFor="medium">Medium</Label>
                      <Input
                        id="medium"
                        value={newArtwork.medium}
                        onChange={(e) => setNewArtwork({ ...newArtwork, medium: e.target.value })}
                        placeholder="Oil on canvas"
                      />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="description">Description</Label>
                    <Textarea
                      id="description"
                      value={newArtwork.description}
                      onChange={(e) => setNewArtwork({ ...newArtwork, description: e.target.value })}
                      placeholder="Describe your artwork..."
                      rows={3}
                    />
                  </div>

                  <Button onClick={handleAddArtwork} className="w-full">
                    <Save className="h-4 w-4 mr-2" />
                    Add Artwork
                  </Button>
                </CardContent>
              )}
            </Card>

            {/* Existing Artworks */}
            <Card>
              <CardHeader>
                <CardTitle>Manage Existing Artwork ({artworks.length})</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4">
                  {artworks.map((artwork) => (
                    <motion.div
                      key={artwork.id}
                      className="flex items-center gap-4 p-4 border rounded-lg"
                      layout
                    >
                      <img
                        src={artwork.image}
                        alt={artwork.title}
                        className="w-16 h-16 object-cover rounded"
                      />
                      
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <h3 className="font-medium truncate">{artwork.title}</h3>
                          {artwork.discount && (
                            <Badge variant="secondary" className="flex items-center gap-1">
                              <Percent className="h-3 w-3" />
                              {artwork.discount}% OFF
                            </Badge>
                          )}
                        </div>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <span className="font-medium text-foreground">${artwork.price}</span>
                          {artwork.originalPrice && (
                            <span className="line-through">${artwork.originalPrice}</span>
                          )}
                          <span>•</span>
                          <span>{artwork.category}</span>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setEditingArtwork(artwork)}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            if (confirm('Are you sure you want to delete this artwork?')) {
                              onDeleteArtwork(artwork.id);
                              toast.success('Artwork deleted successfully');
                            }
                          }}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Content Management Tab */}
          <TabsContent value="content">
            <ContentManagement
              content={siteContent}
              onUpdateContent={onUpdateSiteContent}
            />
          </TabsContent>
        </Tabs>

        {/* Edit Artwork Modal */}
        {editingArtwork && (
          <Dialog open={!!editingArtwork} onOpenChange={() => setEditingArtwork(null)}>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Edit Artwork: {editingArtwork.title}</DialogTitle>
              </DialogHeader>
              
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>Title</Label>
                    <Input
                      value={editingArtwork.title}
                      onChange={(e) =>
                        setEditingArtwork({ ...editingArtwork, title: e.target.value })
                      }
                    />
                  </div>
                  <div>
                    <Label>Category</Label>
                    <Input
                      value={editingArtwork.category}
                      onChange={(e) =>
                        setEditingArtwork({ ...editingArtwork, category: e.target.value })
                      }
                    />
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <Label>Current Price</Label>
                    <Input
                      type="number"
                      value={editingArtwork.price}
                      onChange={(e) =>
                        setEditingArtwork({ ...editingArtwork, price: parseFloat(e.target.value) })
                      }
                    />
                  </div>
                  <div>
                    <Label>Original Price</Label>
                    <Input
                      type="number"
                      value={editingArtwork.originalPrice || ''}
                      onChange={(e) =>
                        setEditingArtwork({
                          ...editingArtwork,
                          originalPrice: e.target.value ? parseFloat(e.target.value) : undefined,
                        })
                      }
                    />
                  </div>
                  <div>
                    <Label>Discount %</Label>
                    <Input
                      type="number"
                      value={editingArtwork.discount || ''}
                      onChange={(e) =>
                        setEditingArtwork({
                          ...editingArtwork,
                          discount: e.target.value ? parseInt(e.target.value) : undefined,
                        })
                      }
                    />
                  </div>
                </div>

                <div>
                  <Label>Description</Label>
                  <Textarea
                    value={editingArtwork.description || ''}
                    onChange={(e) =>
                      setEditingArtwork({ ...editingArtwork, description: e.target.value })
                    }
                    rows={3}
                  />
                </div>

                <div className="flex justify-end gap-2">
                  <Button variant="outline" onClick={() => setEditingArtwork(null)}>
                    Cancel
                  </Button>
                  <Button onClick={() => handleSaveArtwork(editingArtwork)}>
                    <Save className="h-4 w-4 mr-2" />
                    Save Changes
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        )}
      </DialogContent>
    </Dialog>
  );
}