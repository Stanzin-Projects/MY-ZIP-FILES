import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Package, Truck, CheckCircle, Clock, MapPin, Search } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Separator } from './ui/separator';
import { toast } from 'sonner@2.0.3';

export interface Order {
  id: string;
  orderNumber: string;
  date: string;
  status: 'processing' | 'shipped' | 'delivered' | 'cancelled';
  items: {
    id: string;
    title: string;
    image: string;
    price: number;
    quantity: number;
  }[];
  total: number;
  shipping: {
    address: string;
    method: string;
    trackingNumber?: string;
    estimatedDelivery?: string;
  };
  customer: {
    name: string;
    email: string;
  };
  timeline: {
    status: string;
    date: string;
    description: string;
    completed: boolean;
  }[];
}

interface OrderTrackingProps {
  isOpen: boolean;
  onClose: () => void;
}

// Mock orders data
const mockOrders: Order[] = [
  {
    id: '1',
    orderNumber: 'ART-2025-001',
    date: '2025-01-08',
    status: 'shipped',
    items: [
      {
        id: '1',
        title: 'Ethereal Waves',
        image: 'https://images.cdn-files-a.com/uploads/7871374/2000_644d45c730548.png',
        price: 650,
        quantity: 1
      }
    ],
    total: 675,
    shipping: {
      address: '123 Art Street, New York, NY 10001',
      method: 'Express Shipping',
      trackingNumber: 'TRK123456789',
      estimatedDelivery: '2025-01-12'
    },
    customer: {
      name: 'John Doe',
      email: 'john@example.com'
    },
    timeline: [
      {
        status: 'Order Placed',
        date: '2025-01-08 10:30 AM',
        description: 'Your order has been received and is being processed',
        completed: true
      },
      {
        status: 'Payment Confirmed',
        date: '2025-01-08 10:32 AM',
        description: 'Payment has been successfully processed',
        completed: true
      },
      {
        status: 'Preparing for Shipment',
        date: '2025-01-09 2:15 PM',
        description: 'Your artwork is being carefully packaged',
        completed: true
      },
      {
        status: 'Shipped',
        date: '2025-01-10 9:00 AM',
        description: 'Your order is on its way to you',
        completed: true
      },
      {
        status: 'Out for Delivery',
        date: 'Pending',
        description: 'Your order is out for delivery',
        completed: false
      },
      {
        status: 'Delivered',
        date: 'Pending',
        description: 'Your order has been delivered',
        completed: false
      }
    ]
  },
  {
    id: '2',
    orderNumber: 'ART-2025-002',
    date: '2025-01-07',
    status: 'delivered',
    items: [
      {
        id: '3',
        title: 'Mountain Serenity',
        image: 'https://images.cdn-files-a.com/uploads/7871374/2000_644d45b2b6b0b.png',
        price: 350,
        quantity: 1
      }
    ],
    total: 375,
    shipping: {
      address: '456 Creative Ave, Los Angeles, CA 90210',
      method: 'Standard Shipping',
      trackingNumber: 'TRK987654321',
      estimatedDelivery: '2025-01-11'
    },
    customer: {
      name: 'Jane Smith',
      email: 'jane@example.com'
    },
    timeline: [
      {
        status: 'Order Placed',
        date: '2025-01-07 3:20 PM',
        description: 'Your order has been received and is being processed',
        completed: true
      },
      {
        status: 'Payment Confirmed',
        date: '2025-01-07 3:22 PM',
        description: 'Payment has been successfully processed',
        completed: true
      },
      {
        status: 'Preparing for Shipment',
        date: '2025-01-08 11:00 AM',
        description: 'Your artwork is being carefully packaged',
        completed: true
      },
      {
        status: 'Shipped',
        date: '2025-01-09 8:30 AM',
        description: 'Your order is on its way to you',
        completed: true
      },
      {
        status: 'Out for Delivery',
        date: '2025-01-11 8:00 AM',
        description: 'Your order is out for delivery',
        completed: true
      },
      {
        status: 'Delivered',
        date: '2025-01-11 2:45 PM',
        description: 'Your order has been successfully delivered',
        completed: true
      }
    ]
  }
];

export function OrderTracking({ isOpen, onClose }: OrderTrackingProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [searchResults, setSearchResults] = useState<Order[]>([]);

  const handleSearch = () => {
    if (!searchQuery.trim()) {
      toast.error('Please enter an order number or email');
      return;
    }

    const results = mockOrders.filter(order => 
      order.orderNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      order.customer.email.toLowerCase().includes(searchQuery.toLowerCase())
    );

    setSearchResults(results);
    
    if (results.length === 0) {
      toast.error('No orders found. Please check your order number or email.');
    } else {
      toast.success(`Found ${results.length} order(s)`);
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status.toLowerCase()) {
      case 'processing':
      case 'order placed':
      case 'payment confirmed':
        return <Clock className="h-4 w-4" />;
      case 'preparing for shipment':
        return <Package className="h-4 w-4" />;
      case 'shipped':
      case 'out for delivery':
        return <Truck className="h-4 w-4" />;
      case 'delivered':
        return <CheckCircle className="h-4 w-4" />;
      default:
        return <Clock className="h-4 w-4" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case 'processing':
        return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300';
      case 'shipped':
        return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300';
      case 'delivered':
        return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300';
      case 'cancelled':
        return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300';
      default:
        return 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300';
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Package className="h-5 w-5" />
            Track Your Order
          </DialogTitle>
        </DialogHeader>

        {!selectedOrder ? (
          <div className="space-y-6">
            {/* Search Section */}
            <Card>
              <CardHeader>
                <CardTitle>Find Your Order</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex gap-4">
                  <div className="flex-1">
                    <Input
                      placeholder="Enter order number (e.g., ART-2025-001) or email address"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
                    />
                  </div>
                  <Button onClick={handleSearch} className="flex items-center gap-2">
                    <Search className="h-4 w-4" />
                    Search
                  </Button>
                </div>
                
                <p className="text-sm text-muted-foreground">
                  💡 <strong>Demo:</strong> Try searching "ART-2025-001" or "john@example.com" to see order tracking in action.
                </p>
              </CardContent>
            </Card>

            {/* Search Results */}
            {searchResults.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle>Your Orders ({searchResults.length})</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {searchResults.map((order) => (
                      <motion.div
                        key={order.id}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="border rounded-lg p-4 hover:bg-muted/30 cursor-pointer transition-colors"
                        onClick={() => setSelectedOrder(order)}
                      >
                        <div className="flex items-center justify-between mb-3">
                          <div>
                            <h3 className="font-medium">{order.orderNumber}</h3>
                            <p className="text-sm text-muted-foreground">
                              Ordered on {new Date(order.date).toLocaleDateString()}
                            </p>
                          </div>
                          <Badge className={getStatusColor(order.status)}>
                            {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                          </Badge>
                        </div>

                        <div className="flex items-center gap-4">
                          <div className="flex -space-x-2">
                            {order.items.slice(0, 3).map((item, index) => (
                              <img
                                key={index}
                                src={item.image}
                                alt={item.title}
                                className="w-8 h-8 rounded object-cover border-2 border-background"
                              />
                            ))}
                            {order.items.length > 3 && (
                              <div className="w-8 h-8 rounded bg-muted border-2 border-background flex items-center justify-center text-xs">
                                +{order.items.length - 3}
                              </div>
                            )}
                          </div>
                          <div className="flex-1">
                            <p className="text-sm">
                              {order.items.length} item{order.items.length > 1 ? 's' : ''}
                            </p>
                            <p className="font-medium">${order.total}</p>
                          </div>
                          <Button variant="outline" size="sm">
                            Track Order
                          </Button>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        ) : (
          <div className="space-y-6">
            {/* Back Button */}
            <Button
              variant="ghost"
              onClick={() => setSelectedOrder(null)}
              className="mb-4"
            >
              ← Back to Search
            </Button>

            {/* Order Header */}
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h2 className="text-xl font-medium">{selectedOrder.orderNumber}</h2>
                    <p className="text-muted-foreground">
                      Placed on {new Date(selectedOrder.date).toLocaleDateString()}
                    </p>
                  </div>
                  <Badge className={getStatusColor(selectedOrder.status)} size="lg">
                    {selectedOrder.status.charAt(0).toUpperCase() + selectedOrder.status.slice(1)}
                  </Badge>
                </div>

                {selectedOrder.shipping.trackingNumber && (
                  <div className="bg-muted/30 p-4 rounded-lg">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium">Tracking Number</p>
                        <p className="font-mono text-sm">{selectedOrder.shipping.trackingNumber}</p>
                      </div>
                      {selectedOrder.shipping.estimatedDelivery && (
                        <div className="text-right">
                          <p className="font-medium">Estimated Delivery</p>
                          <p className="text-sm">{new Date(selectedOrder.shipping.estimatedDelivery).toLocaleDateString()}</p>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Order Timeline */}
            <Card>
              <CardHeader>
                <CardTitle>Order Timeline</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {selectedOrder.timeline.map((event, index) => (
                    <div key={index} className="flex gap-4">
                      <div className={`mt-1 p-2 rounded-full ${
                        event.completed 
                          ? 'bg-primary text-primary-foreground' 
                          : 'bg-muted text-muted-foreground'
                      }`}>
                        {getStatusIcon(event.status)}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center justify-between mb-1">
                          <h4 className={`font-medium ${event.completed ? '' : 'text-muted-foreground'}`}>
                            {event.status}
                          </h4>
                          <span className="text-sm text-muted-foreground">
                            {event.date}
                          </span>
                        </div>
                        <p className={`text-sm ${event.completed ? '' : 'text-muted-foreground'}`}>
                          {event.description}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Order Items */}
            <Card>
              <CardHeader>
                <CardTitle>Order Items</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {selectedOrder.items.map((item) => (
                    <div key={item.id} className="flex gap-4">
                      <img
                        src={item.image}
                        alt={item.title}
                        className="w-16 h-16 rounded object-cover"
                      />
                      <div className="flex-1">
                        <h4 className="font-medium">{item.title}</h4>
                        <p className="text-muted-foreground">Quantity: {item.quantity}</p>
                        <p className="font-medium">${item.price * item.quantity}</p>
                      </div>
                    </div>
                  ))}
                </div>
                
                <Separator className="my-4" />
                
                <div className="flex justify-between font-medium text-lg">
                  <span>Total</span>
                  <span>${selectedOrder.total}</span>
                </div>
              </CardContent>
            </Card>

            {/* Shipping Information */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MapPin className="h-4 w-4" />
                  Shipping Information
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <p className="font-medium">Delivery Address</p>
                  <p className="text-muted-foreground">{selectedOrder.shipping.address}</p>
                  <p className="text-sm">
                    <strong>Method:</strong> {selectedOrder.shipping.method}
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}