import { useState } from 'react';
import { motion } from 'motion/react';
import { CreditCard, Lock, CheckCircle, ArrowLeft, Package } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Separator } from './ui/separator';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { toast } from 'sonner@2.0.3';
import type { CartItem } from './ShoppingCart';

interface CheckoutProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  onOrderComplete: (orderData: any) => void;
}

// Stripe integration would require these types
interface StripePaymentIntent {
  id: string;
  status: string;
  client_secret: string;
}

export function Checkout({ isOpen, onClose, cartItems, onOrderComplete }: CheckoutProps) {
  const [step, setStep] = useState<'details' | 'payment' | 'success'>('details');
  const [isProcessing, setIsProcessing] = useState(false);
  const [orderNumber, setOrderNumber] = useState('');
  const [customerDetails, setCustomerDetails] = useState({
    email: '',
    firstName: '',
    lastName: '',
    address: '',
    city: '',
    zipCode: '',
    country: '',
  });
  const [paymentDetails, setPaymentDetails] = useState({
    cardNumber: '',
    expiryDate: '',
    cvv: '',
    cardName: '',
  });

  const subtotal = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const shipping = subtotal > 500 ? 0 : 25; // Free shipping over $500
  const tax = subtotal * 0.08; // 8% tax
  const total = subtotal + shipping + tax;

  const handleDetailsNext = () => {
    if (!customerDetails.email || !customerDetails.firstName || !customerDetails.lastName) {
      toast.error('Please fill in all required fields');
      return;
    }
    setStep('payment');
  };

  // Stripe Payment Processing Function
  const processStripePayment = async () => {
    try {
      // In a real implementation, you would:
      // 1. Create a PaymentIntent on your backend
      // 2. Use Stripe Elements for secure card collection
      // 3. Confirm the payment on the client side
      
      const response = await fetch('/api/create-payment-intent', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          amount: Math.round(total * 100), // Stripe expects cents
          currency: 'usd',
          customer: customerDetails,
          items: cartItems.map(item => ({
            name: item.title,
            price: item.price,
            quantity: item.quantity
          }))
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to create payment intent');
      }

      const { client_secret } = await response.json();

      // Confirm payment with Stripe
      // This would use @stripe/stripe-js in a real implementation
      const { error, paymentIntent } = await window.stripe.confirmCardPayment(client_secret, {
        payment_method: {
          card: {
            number: paymentDetails.cardNumber,
            exp_month: parseInt(paymentDetails.expiryDate.split('/')[0]),
            exp_year: parseInt('20' + paymentDetails.expiryDate.split('/')[1]),
            cvc: paymentDetails.cvv,
          },
          billing_details: {
            name: paymentDetails.cardName,
            email: customerDetails.email,
          },
        }
      });

      if (error) {
        throw new Error(error.message);
      }

      return paymentIntent;
    } catch (error) {
      console.error('Stripe payment error:', error);
      throw error;
    }
  };

  const handlePayment = async () => {
    if (!paymentDetails.cardNumber || !paymentDetails.expiryDate || !paymentDetails.cvv) {
      toast.error('Please fill in all payment details');
      return;
    }

    setIsProcessing(true);
    
    try {
      // For demo purposes, we'll simulate the payment
      // In production, uncomment the Stripe integration above
      
      // await processStripePayment();
      
      // Simulate payment processing delay
      await new Promise(resolve => setTimeout(resolve, 3000));
      
      // Generate order number
      const newOrderNumber = `ART-${Date.now().toString().slice(-6)}`;
      setOrderNumber(newOrderNumber);

      // Create order data
      const orderData = {
        orderNumber: newOrderNumber,
        customer: customerDetails,
        items: cartItems,
        total,
        subtotal,
        shipping,
        tax,
        status: 'processing',
        date: new Date().toISOString(),
        paymentMethod: 'Credit Card',
        trackingNumber: `TRK${Date.now().toString().slice(-8)}`
      };

      // In a real app, save order to database
      console.log('Order created:', orderData);
      
      setStep('success');
      toast.success('Payment processed successfully!');
      
      // Clear cart and close after delay
      setTimeout(() => {
        onOrderComplete(orderData);
        onClose();
        resetCheckout();
      }, 4000);
      
    } catch (error: any) {
      toast.error(error.message || 'Payment failed. Please try again.');
      setIsProcessing(false);
    }
  };

  const resetCheckout = () => {
    setStep('details');
    setOrderNumber('');
    setCustomerDetails({
      email: '',
      firstName: '',
      lastName: '',
      address: '',
      city: '',
      zipCode: '',
      country: '',
    });
    setPaymentDetails({
      cardNumber: '',
      expiryDate: '',
      cvv: '',
      cardName: '',
    });
  };

  const formatCardNumber = (value: string) => {
    const v = value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
    const matches = v.match(/\d{4,16}/g);
    const match = matches && matches[0] || '';
    const parts = [];
    for (let i = 0, len = match.length; i < len; i += 4) {
      parts.push(match.substring(i, i + 4));
    }
    if (parts.length) {
      return parts.join(' ');
    } else {
      return v;
    }
  };

  const formatExpiryDate = (value: string) => {
    const v = value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
    if (v.length >= 2) {
      return `${v.substring(0, 2)}/${v.substring(2, 4)}`;
    }
    return v;
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            {step !== 'details' && step !== 'success' && (
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setStep('details')}
              >
                <ArrowLeft className="h-4 w-4" />
              </Button>
            )}
            Secure Checkout
            <Lock className="h-4 w-4 text-muted-foreground" />
          </DialogTitle>
        </DialogHeader>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Order Summary - Always visible */}
          <div>
            <Card>
              <CardHeader>
                <CardTitle>Order Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {cartItems.map((item) => (
                  <div key={item.id} className="flex gap-3">
                    <img
                      src={item.image}
                      alt={item.title}
                      className="w-16 h-16 object-cover rounded"
                    />
                    <div className="flex-1">
                      <h4 className="font-medium">{item.title}</h4>
                      <p className="text-sm text-muted-foreground">
                        Quantity: {item.quantity}
                      </p>
                      <p className="font-medium">${(item.price * item.quantity).toFixed(2)}</p>
                    </div>
                  </div>
                ))}
                
                <Separator />
                
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span>Subtotal</span>
                    <span>${subtotal.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Shipping</span>
                    <span>{shipping === 0 ? 'Free' : `$${shipping.toFixed(2)}`}</span>
                  </div>
                  {shipping === 0 && (
                    <p className="text-xs text-green-600">🎉 Free shipping on orders over $500!</p>
                  )}
                  <div className="flex justify-between">
                    <span>Tax</span>
                    <span>${tax.toFixed(2)}</span>
                  </div>
                  <Separator />
                  <div className="flex justify-between font-medium text-lg">
                    <span>Total</span>
                    <span>${total.toFixed(2)}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Checkout Steps */}
          <div>
            {step === 'details' && (
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
              >
                <Card>
                  <CardHeader>
                    <CardTitle>Customer Details</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label htmlFor="email">Email Address *</Label>
                      <Input
                        id="email"
                        type="email"
                        value={customerDetails.email}
                        onChange={(e) =>
                          setCustomerDetails({ ...customerDetails, email: e.target.value })
                        }
                        placeholder="your@email.com"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="firstName">First Name *</Label>
                        <Input
                          id="firstName"
                          value={customerDetails.firstName}
                          onChange={(e) =>
                            setCustomerDetails({ ...customerDetails, firstName: e.target.value })
                          }
                          placeholder="John"
                        />
                      </div>
                      <div>
                        <Label htmlFor="lastName">Last Name *</Label>
                        <Input
                          id="lastName"
                          value={customerDetails.lastName}
                          onChange={(e) =>
                            setCustomerDetails({ ...customerDetails, lastName: e.target.value })
                          }
                          placeholder="Doe"
                        />
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="address">Address</Label>
                      <Input
                        id="address"
                        value={customerDetails.address}
                        onChange={(e) =>
                          setCustomerDetails({ ...customerDetails, address: e.target.value })
                        }
                        placeholder="123 Art Street"
                      />
                    </div>

                    <div className="grid grid-cols-3 gap-4">
                      <div>
                        <Label htmlFor="city">City</Label>
                        <Input
                          id="city"
                          value={customerDetails.city}
                          onChange={(e) =>
                            setCustomerDetails({ ...customerDetails, city: e.target.value })
                          }
                          placeholder="New York"
                        />
                      </div>
                      <div>
                        <Label htmlFor="zipCode">ZIP Code</Label>
                        <Input
                          id="zipCode"
                          value={customerDetails.zipCode}
                          onChange={(e) =>
                            setCustomerDetails({ ...customerDetails, zipCode: e.target.value })
                          }
                          placeholder="10001"
                        />
                      </div>
                      <div>
                        <Label htmlFor="country">Country</Label>
                        <Input
                          id="country"
                          value={customerDetails.country}
                          onChange={(e) =>
                            setCustomerDetails({ ...customerDetails, country: e.target.value })
                          }
                          placeholder="USA"
                        />
                      </div>
                    </div>

                    <Button onClick={handleDetailsNext} className="w-full" size="lg">
                      Continue to Payment
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            )}

            {step === 'payment' && (
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
              >
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <CreditCard className="h-5 w-5" />
                      Payment Information
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label htmlFor="cardName">Name on Card</Label>
                      <Input
                        id="cardName"
                        value={paymentDetails.cardName}
                        onChange={(e) =>
                          setPaymentDetails({ ...paymentDetails, cardName: e.target.value })
                        }
                        placeholder="John Doe"
                      />
                    </div>

                    <div>
                      <Label htmlFor="cardNumber">Card Number</Label>
                      <Input
                        id="cardNumber"
                        value={paymentDetails.cardNumber}
                        onChange={(e) =>
                          setPaymentDetails({
                            ...paymentDetails,
                            cardNumber: formatCardNumber(e.target.value)
                          })
                        }
                        placeholder="1234 5678 9012 3456"
                        maxLength={19}
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="expiryDate">Expiry Date</Label>
                        <Input
                          id="expiryDate"
                          value={paymentDetails.expiryDate}
                          onChange={(e) =>
                            setPaymentDetails({
                              ...paymentDetails,
                              expiryDate: formatExpiryDate(e.target.value)
                            })
                          }
                          placeholder="MM/YY"
                          maxLength={5}
                        />
                      </div>
                      <div>
                        <Label htmlFor="cvv">CVV</Label>
                        <Input
                          id="cvv"
                          value={paymentDetails.cvv}
                          onChange={(e) =>
                            setPaymentDetails({ ...paymentDetails, cvv: e.target.value })
                          }
                          placeholder="123"
                          maxLength={4}
                        />
                      </div>
                    </div>

                    <div className="p-4 bg-muted/50 rounded-lg">
                      <div className="flex items-center gap-2 mb-2">
                        <Lock className="h-4 w-4 text-green-600" />
                        <span className="text-sm font-medium">Secure Payment with Stripe</span>
                      </div>
                      <p className="text-xs text-muted-foreground">
                        Your payment information is encrypted and secure. We never store your card details.
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">
                        💳 <strong>Demo Mode:</strong> Use card 4242 4242 4242 4242 with any future date and CVV.
                      </p>
                    </div>

                    <Button
                      onClick={handlePayment}
                      disabled={isProcessing}
                      className="w-full"
                      size="lg"
                    >
                      {isProcessing ? (
                        <>
                          <motion.div
                            className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full mr-2"
                            animate={{ rotate: 360 }}
                            transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                          />
                          Processing Payment...
                        </>
                      ) : (
                        <>
                          <Lock className="h-4 w-4 mr-2" />
                          Pay ${total.toFixed(2)}
                        </>
                      )}
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            )}

            {step === 'success' && (
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="text-center py-8"
              >
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: 0.2, type: "spring" }}
                >
                  <CheckCircle className="h-16 w-16 text-green-500 mx-auto mb-4" />
                </motion.div>
                <h2 className="text-2xl font-medium mb-2">Payment Successful!</h2>
                <p className="text-muted-foreground mb-4">
                  Thank you for your purchase. You will receive a confirmation email shortly.
                </p>
                <div className="p-4 bg-green-50 dark:bg-green-900/20 rounded-lg mb-4">
                  <div className="flex items-center justify-center gap-2 mb-2">
                    <Package className="h-4 w-4 text-green-600" />
                    <p className="font-medium text-green-700 dark:text-green-400">
                      Order #{orderNumber}
                    </p>
                  </div>
                  <p className="text-sm text-green-700 dark:text-green-400">
                    Total: ${total.toFixed(2)}
                  </p>
                </div>
                <p className="text-sm text-muted-foreground">
                  You can track your order status anytime using your order number.
                </p>
              </motion.div>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}