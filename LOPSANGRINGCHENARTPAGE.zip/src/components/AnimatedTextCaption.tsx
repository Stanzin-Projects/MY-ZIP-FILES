import { useState, useEffect } from 'react';

interface AnimatedTextCaptionProps {
  className?: string;
  textSize?: string;
  animationDuration?: number;
  customCaptions?: string[];
}

export function AnimatedTextCaption({ 
  className = "", 
  textSize = "text-3xl sm:text-4xl md:text-5xl lg:text-6xl xl:text-7xl",
  animationDuration = 4000,
  customCaptions
}: AnimatedTextCaptionProps) {
  const defaultCaptions = [
    "Bringing Imagination to Paper",
    "Lines That Speak Stories", 
    "Every Sketch Has a Soul",
    "Art in Every Stroke",
    "Shadows and Light in Harmony"
  ];

  const captions = customCaptions || defaultCaptions;
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isVisible, setIsVisible] = useState(true);
  const [isSliding, setIsSliding] = useState(false);

  useEffect(() => {
    const interval = setInterval(() => {
      // Start exit animation
      setIsVisible(false);
      setIsSliding(true);
      
      setTimeout(() => {
        // Change text
        setCurrentIndex((prev) => (prev + 1) % captions.length);
        
        setTimeout(() => {
          // Start enter animation
          setIsVisible(true);
          setIsSliding(false);
        }, 100);
      }, 400);
    }, animationDuration);

    return () => clearInterval(interval);
  }, [captions.length, animationDuration]);

  return (
    <div className={`relative overflow-hidden ${className}`}>
      <h1 
        className={`font-medium leading-tight transition-all duration-500 ease-in-out transform ${textSize} ${
          isVisible 
            ? 'opacity-100 translate-y-0 scale-100' 
            : 'opacity-0 translate-y-3 scale-98'
        } ${
          isSliding ? 'translate-x-2' : 'translate-x-0'
        }`}
        style={{
          transitionTimingFunction: 'cubic-bezier(0.25, 0.46, 0.45, 0.94)',
        }}
      >
        <span className="block">
          {captions[currentIndex]}
        </span>
      </h1>
      
      {/* Subtle animated underline */}
      <div 
        className={`h-1 bg-gradient-to-r from-primary to-accent rounded-full mt-4 transition-all duration-700 ease-out ${
          isVisible ? 'w-16 opacity-60' : 'w-0 opacity-0'
        }`}
      />
    </div>
  );
}