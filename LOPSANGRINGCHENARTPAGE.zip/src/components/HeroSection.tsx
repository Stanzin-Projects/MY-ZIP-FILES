import { ArrowDown, Star } from "lucide-react";
import { Button } from "./ui/button";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { AnimatedTextCaption } from "./AnimatedTextCaption";

interface HeroSectionProps {
  siteContent?: {
    hero: {
      title: string;
      subtitle: string;
      description: string;
      ctaText: string;
      backgroundImage: string;
    };
  };
}

export function HeroSection({ siteContent }: HeroSectionProps) {
  const heroData = siteContent?.hero || {
    title: "Where Art Meets Soul",
    subtitle: "Discover unique artworks that speak to your heart",
    description: "From abstract expressions to realistic portraits, each piece tells a story waiting to be part of yours.",
    ctaText: "Explore Gallery",
    backgroundImage: "https://images.cdn-files-a.com/uploads/7871374/2000_644d45ca0954b.png"
  };



  return (
    <section
      id="home"
      className="min-h-screen flex items-center justify-center relative overflow-hidden"
    >
      {/* Simple Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="w-full h-full bg-gradient-to-br from-primary to-accent" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid lg:grid-cols-2 gap-8 lg:gap-12 items-center">
        {/* Text Content - No Animations */}
        <div className="space-y-8">
          <div className="flex items-center space-x-2 text-muted-foreground">
            <Star className="h-5 w-5 fill-current text-yellow-400" />
            <span>Original Artwork & Prints</span>
          </div>

          <AnimatedTextCaption />

          <p className="text-base sm:text-lg text-muted-foreground max-w-md">
            {heroData.subtitle}. {heroData.description}
          </p>

          <div className="flex flex-col sm:flex-row gap-4">
            <Button size="lg" asChild>
              <a href="#gallery">
                {heroData.ctaText}
                <span className="ml-2">→</span>
              </a>
            </Button>

            <Button variant="outline" size="lg" asChild className="border-0">
              <a href="#contact">Commission Art</a>
            </Button>
          </div>
        </div>

        {/* Featured Artwork - Simple, Clean, No Decorative Elements */}
        <div className="relative">
          <ImageWithFallback
            src={heroData.backgroundImage}
            alt="Featured Artwork by Lopsang"
            className="w-full aspect-[3/4] object-cover rounded-2xl"
          />
        </div>
      </div>

      {/* Scroll Indicator - Keep This Animation Since It's Functional */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2">
        <ArrowDown className="h-6 w-6 text-muted-foreground animate-bounce" />
      </div>
    </section>
  );
}