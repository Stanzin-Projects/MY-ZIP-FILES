import { useState } from 'react';
import { motion } from 'motion/react';
import { Edit, Save, Image, Type, Mail, Phone, MapPin, Globe, Percent, Calendar, ToggleLeft, ToggleRight } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Label } from './ui/label';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Switch } from './ui/switch';
import { toast } from 'sonner@2.0.3';

export interface OfferSettings {
  enabled: boolean;
  title: string;
  description: string;
  discountPercentage: number;
  startDate: string;
  endDate: string;
  applicableCategories: string[];
  minimumPurchase: number;
}

export interface SiteContent {
  hero: {
    title: string;
    subtitle: string;
    description: string;
    ctaText: string;
    backgroundImage: string;
  };
  about: {
    title: string;
    subtitle: string;
    description: string;
    image: string;
    stats: {
      label: string;
      value: string;
    }[];
  };
  contact: {
    title: string;
    description: string;
    email: string;
    phone: string;
    address: string;
    website: string;
  };
  general: {
    siteName: string;
    logo: string;
    tagline: string;
  };
  offers: OfferSettings;
}

interface ContentManagementProps {
  content: SiteContent;
  onUpdateContent: (content: SiteContent) => void;
}

export function ContentManagement({ content, onUpdateContent }: ContentManagementProps) {
  const [editingContent, setEditingContent] = useState<SiteContent>(content);
  const [activeTab, setActiveTab] = useState('general');

  const handleSave = () => {
    onUpdateContent(editingContent);
    toast.success('Site content updated successfully!');
  };

  const updateSection = <K extends keyof SiteContent>(
    section: K,
    updates: Partial<SiteContent[K]>
  ) => {
    setEditingContent(prev => ({
      ...prev,
      [section]: {
        ...prev[section],
        ...updates
      }
    }));
  };

  const isOfferActive = () => {
    if (!editingContent.offers.enabled) return false;
    
    const now = new Date();
    const startDate = new Date(editingContent.offers.startDate);
    const endDate = new Date(editingContent.offers.endDate);
    
    return now >= startDate && now <= endDate;
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-medium">Content Management</h2>
        <Button onClick={handleSave} className="flex items-center gap-2">
          <Save className="h-4 w-4" />
          Save All Changes
        </Button>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="general">General</TabsTrigger>
          <TabsTrigger value="hero">Hero</TabsTrigger>
          <TabsTrigger value="about">About</TabsTrigger>
          <TabsTrigger value="contact">Contact</TabsTrigger>
          <TabsTrigger value="offers">Offers</TabsTrigger>
        </TabsList>

        {/* General Settings */}
        <TabsContent value="general">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Globe className="h-5 w-5" />
                General Site Settings
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="siteName">Site Name</Label>
                <Input
                  id="siteName"
                  value={editingContent.general.siteName}
                  onChange={(e) => updateSection('general', { siteName: e.target.value })}
                  placeholder="ARTBYLOPSANG"
                />
              </div>

              <div>
                <Label htmlFor="logo">Logo URL</Label>
                <Input
                  id="logo"
                  value={editingContent.general.logo}
                  onChange={(e) => updateSection('general', { logo: e.target.value })}
                  placeholder="https://your-logo-url.com"
                />
              </div>

              <div>
                <Label htmlFor="tagline">Site Tagline</Label>
                <Input
                  id="tagline"
                  value={editingContent.general.tagline}
                  onChange={(e) => updateSection('general', { tagline: e.target.value })}
                  placeholder="Creating meaningful art that transforms spaces"
                />
              </div>

              {editingContent.general.logo && (
                <div>
                  <Label>Logo Preview</Label>
                  <div className="mt-2 p-4 border rounded-lg bg-muted/20">
                    <img
                      src={editingContent.general.logo}
                      alt="Logo preview"
                      className="h-12 w-auto object-contain"
                    />
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Hero Section */}
        <TabsContent value="hero">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Type className="h-5 w-5" />
                Hero Section
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="heroTitle">Main Title</Label>
                <Input
                  id="heroTitle"
                  value={editingContent.hero.title}
                  onChange={(e) => updateSection('hero', { title: e.target.value })}
                  placeholder="Art that Speaks to Your Soul"
                />
              </div>

              <div>
                <Label htmlFor="heroSubtitle">Subtitle</Label>
                <Input
                  id="heroSubtitle"
                  value={editingContent.hero.subtitle}
                  onChange={(e) => updateSection('hero', { subtitle: e.target.value })}
                  placeholder="Discover unique artworks that transform spaces"
                />
              </div>

              <div>
                <Label htmlFor="heroDescription">Description</Label>
                <Textarea
                  id="heroDescription"
                  value={editingContent.hero.description}
                  onChange={(e) => updateSection('hero', { description: e.target.value })}
                  placeholder="Explore our curated collection of original paintings..."
                  rows={3}
                />
              </div>

              <div>
                <Label htmlFor="heroCtaText">Call-to-Action Button Text</Label>
                <Input
                  id="heroCtaText"
                  value={editingContent.hero.ctaText}
                  onChange={(e) => updateSection('hero', { ctaText: e.target.value })}
                  placeholder="Explore Gallery"
                />
              </div>

              <div>
                <Label htmlFor="heroBackground">Background Image URL</Label>
                <Input
                  id="heroBackground"
                  value={editingContent.hero.backgroundImage}
                  onChange={(e) => updateSection('hero', { backgroundImage: e.target.value })}
                  placeholder="https://your-hero-image-url.com"
                />
              </div>

              {editingContent.hero.backgroundImage && (
                <div>
                  <Label>Background Preview</Label>
                  <div className="mt-2 relative h-32 rounded-lg overflow-hidden bg-muted/20">
                    <img
                      src={editingContent.hero.backgroundImage}
                      alt="Hero background preview"
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                      <div className="text-center text-white">
                        <h3 className="font-medium">{editingContent.hero.title}</h3>
                        <p className="text-sm opacity-80">{editingContent.hero.subtitle}</p>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* About Section */}
        <TabsContent value="about">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Edit className="h-5 w-5" />
                About Section
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="aboutTitle">Section Title</Label>
                <Input
                  id="aboutTitle"
                  value={editingContent.about.title}
                  onChange={(e) => updateSection('about', { title: e.target.value })}
                  placeholder="About the Artist"
                />
              </div>

              <div>
                <Label htmlFor="aboutSubtitle">Subtitle</Label>
                <Input
                  id="aboutSubtitle"
                  value={editingContent.about.subtitle}
                  onChange={(e) => updateSection('about', { subtitle: e.target.value })}
                  placeholder="Creating meaningful connections through art"
                />
              </div>

              <div>
                <Label htmlFor="aboutDescription">Description</Label>
                <Textarea
                  id="aboutDescription"
                  value={editingContent.about.description}
                  onChange={(e) => updateSection('about', { description: e.target.value })}
                  placeholder="Tell your story as an artist..."
                  rows={4}
                />
              </div>

              <div>
                <Label htmlFor="aboutImage">About Image URL</Label>
                <Input
                  id="aboutImage"
                  value={editingContent.about.image}
                  onChange={(e) => updateSection('about', { image: e.target.value })}
                  placeholder="https://your-about-image-url.com"
                />
              </div>

              {/* Stats */}
              <div>
                <Label>Statistics</Label>
                <div className="space-y-2 mt-2">
                  {editingContent.about.stats.map((stat, index) => (
                    <div key={index} className="grid grid-cols-2 gap-2">
                      <Input
                        value={stat.value}
                        onChange={(e) => {
                          const newStats = [...editingContent.about.stats];
                          newStats[index] = { ...stat, value: e.target.value };
                          updateSection('about', { stats: newStats });
                        }}
                        placeholder="100+"
                      />
                      <Input
                        value={stat.label}
                        onChange={(e) => {
                          const newStats = [...editingContent.about.stats];
                          newStats[index] = { ...stat, label: e.target.value };
                          updateSection('about', { stats: newStats });
                        }}
                        placeholder="Artworks Created"
                      />
                    </div>
                  ))}
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      const newStats = [...editingContent.about.stats, { value: '', label: '' }];
                      updateSection('about', { stats: newStats });
                    }}
                  >
                    Add Stat
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Contact Section */}
        <TabsContent value="contact">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Mail className="h-5 w-5" />
                Contact Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="contactTitle">Section Title</Label>
                <Input
                  id="contactTitle"
                  value={editingContent.contact.title}
                  onChange={(e) => updateSection('contact', { title: e.target.value })}
                  placeholder="Get in Touch"
                />
              </div>

              <div>
                <Label htmlFor="contactDescription">Description</Label>
                <Textarea
                  id="contactDescription"
                  value={editingContent.contact.description}
                  onChange={(e) => updateSection('contact', { description: e.target.value })}
                  placeholder="Let's discuss your next art project..."
                  rows={2}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="contactEmail">Email</Label>
                  <Input
                    id="contactEmail"
                    type="email"
                    value={editingContent.contact.email}
                    onChange={(e) => updateSection('contact', { email: e.target.value })}
                    placeholder="artist@example.com"
                  />
                </div>

                <div>
                  <Label htmlFor="contactPhone">Phone</Label>
                  <Input
                    id="contactPhone"
                    value={editingContent.contact.phone}
                    onChange={(e) => updateSection('contact', { phone: e.target.value })}
                    placeholder="+1 (555) 123-4567"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="contactAddress">Address</Label>
                <Input
                  id="contactAddress"
                  value={editingContent.contact.address}
                  onChange={(e) => updateSection('contact', { address: e.target.value })}
                  placeholder="123 Art Street, Creative City, NY 10001"
                />
              </div>

              <div>
                <Label htmlFor="contactWebsite">Website</Label>
                <Input
                  id="contactWebsite"
                  value={editingContent.contact.website}
                  onChange={(e) => updateSection('contact', { website: e.target.value })}
                  placeholder="https://your-website.com"
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Offers Management */}
        <TabsContent value="offers">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Percent className="h-5 w-5" />
                Offer Management
                {isOfferActive() && (
                  <span className="ml-2 px-2 py-1 bg-green-100 text-green-800 text-xs rounded-full">
                    Active
                  </span>
                )}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Enable/Disable Offer */}
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="offerEnabled">Enable Offers</Label>
                  <p className="text-sm text-muted-foreground">
                    Turn on/off the offer system for your artworks
                  </p>
                </div>
                <Switch
                  id="offerEnabled"
                  checked={editingContent.offers.enabled}
                  onCheckedChange={(checked) => updateSection('offers', { enabled: checked })}
                />
              </div>

              {editingContent.offers.enabled && (
                <>
                  {/* Offer Details */}
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="offerTitle">Offer Title</Label>
                      <Input
                        id="offerTitle"
                        value={editingContent.offers.title}
                        onChange={(e) => updateSection('offers', { title: e.target.value })}
                        placeholder="Holiday Sale"
                      />
                    </div>

                    <div>
                      <Label htmlFor="offerDiscount">Discount Percentage</Label>
                      <Input
                        id="offerDiscount"
                        type="number"
                        min="1"
                        max="100"
                        value={editingContent.offers.discountPercentage}
                        onChange={(e) => updateSection('offers', { discountPercentage: parseInt(e.target.value) || 0 })}
                        placeholder="20"
                      />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="offerDescription">Offer Description</Label>
                    <Textarea
                      id="offerDescription"
                      value={editingContent.offers.description}
                      onChange={(e) => updateSection('offers', { description: e.target.value })}
                      placeholder="Limited time offer on selected artworks..."
                      rows={2}
                    />
                  </div>

                  {/* Date Range */}
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="offerStartDate">Start Date</Label>
                      <Input
                        id="offerStartDate"
                        type="datetime-local"
                        value={editingContent.offers.startDate}
                        onChange={(e) => updateSection('offers', { startDate: e.target.value })}
                      />
                    </div>

                    <div>
                      <Label htmlFor="offerEndDate">End Date</Label>
                      <Input
                        id="offerEndDate"
                        type="datetime-local"
                        value={editingContent.offers.endDate}
                        onChange={(e) => updateSection('offers', { endDate: e.target.value })}
                      />
                    </div>
                  </div>

                  {/* Minimum Purchase */}
                  <div>
                    <Label htmlFor="minimumPurchase">Minimum Purchase Amount ($)</Label>
                    <Input
                      id="minimumPurchase"
                      type="number"
                      min="0"
                      value={editingContent.offers.minimumPurchase}
                      onChange={(e) => updateSection('offers', { minimumPurchase: parseFloat(e.target.value) || 0 })}
                      placeholder="0"
                    />
                    <p className="text-sm text-muted-foreground mt-1">
                      Set to 0 for no minimum purchase requirement
                    </p>
                  </div>

                  {/* Applicable Categories */}
                  <div>
                    <Label>Applicable Categories</Label>
                    <div className="mt-2 space-y-2">
                      {['All', 'Abstract', 'Portrait', 'Landscape', 'Urban', 'Still Life'].map((category) => (
                        <div key={category} className="flex items-center space-x-2">
                          <input
                            type="checkbox"
                            id={`category-${category}`}
                            checked={editingContent.offers.applicableCategories.includes(category)}
                            onChange={(e) => {
                              const categories = editingContent.offers.applicableCategories;
                              if (e.target.checked) {
                                updateSection('offers', { 
                                  applicableCategories: [...categories, category] 
                                });
                              } else {
                                updateSection('offers', { 
                                  applicableCategories: categories.filter(c => c !== category) 
                                });
                              }
                            }}
                            className="rounded"
                          />
                          <label htmlFor={`category-${category}`} className="text-sm">
                            {category}
                          </label>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Offer Preview */}
                  <div className="p-4 bg-muted/30 rounded-lg">
                    <h4 className="font-medium mb-2">Offer Preview</h4>
                    <div className="space-y-1 text-sm">
                      <p><strong>Title:</strong> {editingContent.offers.title || 'No title set'}</p>
                      <p><strong>Discount:</strong> {editingContent.offers.discountPercentage}% off</p>
                      <p><strong>Valid:</strong> {editingContent.offers.startDate ? new Date(editingContent.offers.startDate).toLocaleDateString() : 'No start date'} - {editingContent.offers.endDate ? new Date(editingContent.offers.endDate).toLocaleDateString() : 'No end date'}</p>
                      <p><strong>Categories:</strong> {editingContent.offers.applicableCategories.join(', ') || 'None selected'}</p>
                      <p><strong>Minimum Purchase:</strong> ${editingContent.offers.minimumPurchase}</p>
                      <p><strong>Status:</strong> {isOfferActive() ? '🟢 Active' : '🔴 Inactive'}</p>
                    </div>
                  </div>
                </>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}