import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Search, Filter, Grid, List, Heart, ShoppingCart, Percent } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card, CardContent } from './ui/card';
import { Badge } from './ui/badge';
import { ImageWithFallback } from './figma/ImageWithFallback';

export interface Artwork {
  id: string;
  title: string;
  price: number;
  originalPrice?: number;
  discount?: number;
  category: string;
  image: string;
  description: string;
  dimensions: string;
  medium: string;
  isOriginal?: boolean;
}

interface ArtGalleryProps {
  onAddToCart: (artwork: Artwork) => void;
  onArtworkClick: (artwork: Artwork) => void;
  artworks?: Artwork[];
}

// Default artworks data
const defaultArtworks: Artwork[] = [
  {
    id: '1',
    title: 'Ethereal Waves',
    price: 650,
    originalPrice: 800,
    discount: 19,
    category: 'Abstract',
    image: 'https://images.cdn-files-a.com/uploads/7871374/2000_644d45c730548.png',
    description: 'A fluid exploration of movement and color',
    dimensions: '24" x 36"',
    medium: 'Acrylic on Canvas',
    isOriginal: true
  },
  {
    id: '2',
    title: 'Urban Symphony',
    price: 450,
    category: 'Urban',
    image: 'https://images.cdn-files-a.com/uploads/7871374/2000_644d45c912fd4.png',
    description: 'Capturing the rhythm of city life',
    dimensions: '20" x 30"',
    medium: 'Mixed Media',
    isOriginal: true
  },
  {
    id: '3',
    title: 'Mountain Serenity',
    price: 350,
    originalPrice: 450,
    discount: 22,
    category: 'Landscape',
    image: 'https://images.cdn-files-a.com/uploads/7871374/2000_644d45b2b6b0b.png',
    description: 'Peaceful mountain landscape at dawn',
    dimensions: '18" x 24"',
    medium: 'Oil on Canvas',
    isOriginal: false
  },
  {
    id: '4',
    title: 'Portrait of Grace',
    price: 800,
    category: 'Portrait',
    image: 'https://images.cdn-files-a.com/uploads/7871374/2000_644d45b8d4ae7.png',
    description: 'A study in light and emotion',
    dimensions: '16" x 20"',
    medium: 'Charcoal on Paper',
    isOriginal: true
  },
  {
    id: '5',
    title: 'Color Burst',
    price: 520,
    originalPrice: 650,
    discount: 20,
    category: 'Abstract',
    image: 'https://images.cdn-files-a.com/uploads/7871374/2000_644d45c912fd4.png',
    description: 'An explosion of vibrant colors and energy',
    dimensions: '22" x 28"',
    medium: 'Acrylic on Canvas',
    isOriginal: true
  },
  {
    id: '6',
    title: 'Still Life Elegance',
    price: 380,
    category: 'Still Life',
    image: 'https://images.cdn-files-a.com/uploads/7871374/2000_644d45ca0954b.png',
    description: 'Classical still life with modern twist',
    dimensions: '16" x 20"',
    medium: 'Oil on Canvas',
    isOriginal: false
  }
];

export function ArtGallery({ onAddToCart, onArtworkClick, artworks = defaultArtworks }: ArtGalleryProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [favorites, setFavorites] = useState<Set<string>>(new Set());

  // Get unique categories from artworks
  const categories = ['All', ...Array.from(new Set(artworks.map(artwork => artwork.category)))];

  const filteredArtworks = artworks.filter(artwork => {
    const matchesSearch = artwork.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         artwork.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || artwork.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const toggleFavorite = (artworkId: string) => {
    setFavorites(prev => {
      const newFavorites = new Set(prev);
      if (newFavorites.has(artworkId)) {
        newFavorites.delete(artworkId);
      } else {
        newFavorites.add(artworkId);
      }
      return newFavorites;
    });
  };

  return (
    <section id="gallery" className="py-16 lg:py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header - Minimal Animation */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl md:text-4xl font-medium mb-4">Art Gallery</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Explore our collection of original artworks and limited edition prints. 
            Each piece is carefully crafted to bring beauty and meaning to your space.
          </p>
        </motion.div>

        {/* Filters and Search - Minimal Animation */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-8 space-y-4"
        >
          {/* Search and View Toggle - Responsive */}
          <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 items-stretch sm:items-center justify-between">
            <div className="relative flex-1 w-full sm:max-w-md">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search artworks..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 h-10"
              />
            </div>

            <div className="flex items-center gap-2 justify-center sm:justify-start">
              <Button
                variant={viewMode === 'grid' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setViewMode('grid')}
                className="flex items-center gap-1 sm:gap-2"
              >
                <Grid className="h-4 w-4" />
                <span className="hidden sm:inline">Grid</span>
              </Button>
              <Button
                variant={viewMode === 'list' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setViewMode('list')}
                className="flex items-center gap-1 sm:gap-2"
              >
                <List className="h-4 w-4" />
                <span className="hidden sm:inline">List</span>
              </Button>
            </div>
          </div>

          {/* Category Filter - Responsive Scroll */}
          <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
            {categories.map((category) => (
              <Button
                key={category}
                variant={selectedCategory === category ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedCategory(category)}
                className="whitespace-nowrap text-sm"
              >
                {category}
              </Button>
            ))}
          </div>
        </motion.div>

        {/* Artwork Grid - Fully Responsive for All Devices */}
        <AnimatePresence>
          <motion.div
            className={`grid gap-4 sm:gap-6 ${
              viewMode === 'grid' 
                ? 'grid-cols-1 xs:grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 2xl:grid-cols-6' 
                : 'grid-cols-1'
            }`}
            layout
          >
            {filteredArtworks.map((artwork, index) => (
              <motion.div
                key={artwork.id}
                layout
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.3 }}
                className="cursor-pointer"
                onClick={() => onArtworkClick(artwork)}
              >
                {/* Borderless Card - Completely Transparent */}
                <div className="bg-transparent">
                  <div className="relative">
                    <ImageWithFallback
                      src={artwork.image}
                      alt={artwork.title}
                      className={`w-full ${
                        viewMode === 'grid' ? 'aspect-[3/4] sm:aspect-[4/5] md:aspect-[3/4]' : 'aspect-[16/9] sm:aspect-[3/2] md:aspect-[2/1]'
                      } object-cover rounded-lg transition-transform duration-200`}
                    />
                    
                    {/* Responsive Action Buttons - Always Visible */}
                    <div className="absolute top-2 right-2 sm:top-4 sm:right-4 flex gap-1 sm:gap-2">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          toggleFavorite(artwork.id);
                        }}
                        className="p-1.5 sm:p-2 bg-white/90 rounded-full shadow-sm hover:bg-white transition-colors"
                      >
                        <Heart 
                          className={`h-3 w-3 sm:h-4 sm:w-4 ${
                            favorites.has(artwork.id) 
                              ? 'fill-red-500 text-red-500' 
                              : 'text-gray-600'
                          }`} 
                        />
                      </button>
                      
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onAddToCart(artwork);
                        }}
                        className="p-1.5 sm:p-2 bg-white/90 rounded-full shadow-sm hover:bg-white transition-colors"
                      >
                        <ShoppingCart className="h-3 w-3 sm:h-4 sm:w-4 text-gray-600" />
                      </button>
                    </div>

                    {/* Responsive Badges */}
                    <div className="absolute top-2 left-2 sm:top-4 sm:left-4 flex flex-col sm:flex-row gap-1 sm:gap-2">
                      {artwork.isOriginal && (
                        <Badge variant="secondary" className="text-xs">Original</Badge>
                      )}
                      {artwork.discount && (
                        <Badge variant="destructive" className="flex items-center gap-1 text-xs">
                          <Percent className="h-2 w-2 sm:h-3 sm:w-3" />
                          {artwork.discount}% OFF
                        </Badge>
                      )}
                    </div>
                  </div>

                  {/* Content Area - Responsive Layout */}
                  <div className="p-3 sm:p-4 md:p-6 bg-transparent">
                    <div className="space-y-2 sm:space-y-3">
                      <div className="flex flex-col sm:flex-row sm:justify-between sm:items-start gap-2">
                        <div className="flex-1">
                          <h3 className="font-medium text-base sm:text-lg truncate">{artwork.title}</h3>
                          <p className="text-muted-foreground text-xs sm:text-sm">{artwork.medium}</p>
                        </div>
                        <div className="text-left sm:text-right">
                          <div className="flex items-center gap-2">
                            <p className="font-medium text-base sm:text-lg">${artwork.price}</p>
                            {artwork.originalPrice && (
                              <p className="text-muted-foreground text-xs sm:text-sm line-through">
                                ${artwork.originalPrice}
                              </p>
                            )}
                          </div>
                          <p className="text-muted-foreground text-xs sm:text-sm">{artwork.dimensions}</p>
                        </div>
                      </div>
                      
                      <p className="text-muted-foreground text-xs sm:text-sm line-clamp-2">
                        {artwork.description}
                      </p>

                      <div className="flex justify-between items-center pt-1 sm:pt-2">
                        <Badge variant="outline" className="text-xs">{artwork.category}</Badge>
                        <Button size="sm" className="text-xs sm:text-sm">View Details</Button>
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </AnimatePresence>

        {filteredArtworks.length === 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-12"
          >
            <p className="text-muted-foreground">No artworks found matching your criteria.</p>
          </motion.div>
        )}
      </div>
    </section>
  );
}