import { Palette, Award, Users, Heart } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { AnimatedTextCaption } from './AnimatedTextCaption';

const defaultStats = [
  { icon: Palette, label: 'Artworks Created', value: '200+' },
  { icon: Award, label: 'Exhibitions', value: '15' },
  { icon: Users, label: 'Happy Collectors', value: '500+' },
  { icon: Heart, label: 'Years of Passion', value: '12' }
];

interface AboutSectionProps {
  siteContent?: {
    about: {
      title: string;
      subtitle: string;
      description: string;
      image: string;
      stats: { value: string; label: string }[];
    };
  };
}

export function AboutSection({ siteContent }: AboutSectionProps) {
  const aboutData = siteContent?.about || {
    title: "About the Artist",
    subtitle: "Creating meaningful connections through art",
    description: "With over a decade of experience in contemporary art, I create pieces that bridge the gap between traditional techniques and modern expression. My work explores themes of nature, human emotion, and the interconnectedness of all things.",
    // image: "https://images.cdn-files-a.com/uploads/7871374/2000_644a7ebe3625f_filter_645ca89d0848f.png.",
    image: "https://images.cdn-files-a.com/uploads/7871374/2000_644a7ebe3625f_filter_645ca89d0848f.png",
    stats: [
      { value: '200+', label: 'Artworks Created' },
      { value: '15', label: 'Exhibitions' },
      { value: '500+', label: 'Happy Collectors' },
      { value: '12', label: 'Years of Passion' }
    ]
  };

  // Map stats to icons
  const statsWithIcons = aboutData.stats.map((stat, index) => ({
    ...stat,
    icon: defaultStats[index]?.icon || Palette
  }));

  return (
    <section id="about" className="py-12 sm:py-16 lg:py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Responsive Grid Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 sm:gap-12 lg:gap-16 items-start lg:items-center">
          {/* Text Content - Responsive Typography and Spacing */}
          <div className="space-y-6 sm:space-y-8 order-2 lg:order-1">
            <div className="space-y-4 sm:space-y-6">
              <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-4xl xl:text-5xl font-medium leading-tight">
                {aboutData.title}
              </h2>
              {/* Animated subtitle with art-focused captions */}
              <div className="mb-2">
                <AnimatedTextCaption 
                  textSize="text-base sm:text-lg lg:text-xl"
                  className="text-muted-foreground"
                  customCaptions={[
                    "Creating meaningful connections through art",
                    "Where tradition meets modern expression", 
                    "Transforming spaces with intentional art",
                    "From Zanskar valleys to global galleries",
                    "Art that speaks to the soul"
                  ]}
                  animationDuration={5000}
                />
              </div>
              <div className="space-y-3 sm:space-y-4 text-sm sm:text-base text-muted-foreground leading-relaxed">
                <p>{aboutData.description}</p>
                <p>
                  Born and raised in Zanskar, Thangso where the total number of houses is no more than 10, 
                  I've been creating art for over a decade. My inspiration comes from the vibrant energy of 
                  urban life, the serenity of nature, and the complex emotions of human experience.
                </p>
                <p>
                  I believe art should not just decorate spaces but transform them, creating environments 
                  that inspire, comfort, and provoke thought. Whether you're looking for a statement piece 
                  or something more intimate, each artwork is created with intention and love.
                </p>
              </div>
            </div>

            {/* Responsive Stats Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-2 xl:grid-cols-4 gap-4 sm:gap-6 pt-4">
              {statsWithIcons.map((stat) => (
                <div key={stat.label} className="text-center">
                  <div className="w-10 h-10 sm:w-12 sm:h-12 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-2 sm:mb-3">
                    <stat.icon className="h-5 w-5 sm:h-6 sm:w-6 text-primary" />
                  </div>
                  <p className="text-lg sm:text-xl lg:text-2xl font-medium">{stat.value}</p>
                  <p className="text-xs sm:text-sm text-muted-foreground leading-tight">{stat.label}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Image Section - Responsive Layout */}
          <div className="space-y-4 sm:space-y-6 order-1 lg:order-2">
            {/* Artist Image - Responsive Aspect Ratios */}
            <div className="relative">
              <ImageWithFallback
                src={aboutData.image}
                alt="Artist in studio"
                className="w-full aspect-[3/4] sm:aspect-[4/5] lg:aspect-[3/4] xl:aspect-[4/5] object-cover rounded-lg"
              />
            </div>

            {/* Process Cards - Responsive Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
              <div className="p-3 sm:p-4 text-center bg-transparent">
                <h4 className="font-medium mb-1 sm:mb-2 text-sm sm:text-base">Inspiration</h4>
                <p className="text-xs sm:text-sm text-muted-foreground leading-relaxed">
                  Drawing from life experiences and emotions
                </p>
              </div>
              
              <div className="p-3 sm:p-4 text-center bg-transparent">
                <h4 className="font-medium mb-1 sm:mb-2 text-sm sm:text-base">Creation</h4>
                <p className="text-xs sm:text-sm text-muted-foreground leading-relaxed">
                  Bringing visions to life through various mediums
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}