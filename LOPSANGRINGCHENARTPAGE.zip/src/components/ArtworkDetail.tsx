import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Heart, Share2, Download, ShoppingCart, Palette } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { ImageWithFallback } from './figma/ImageWithFallback';
import type { Artwork } from './ArtGallery';

interface ArtworkDetailProps {
  artwork: Artwork | null;
  isOpen: boolean;
  onClose: () => void;
  onAddToCart: (artwork: Artwork) => void;
  isFavorite: boolean;
  onToggleFavorite: () => void;
}

export function ArtworkDetail({ 
  artwork, 
  isOpen, 
  onClose, 
  onAddToCart, 
  isFavorite, 
  onToggleFavorite 
}: ArtworkDetailProps) {
  const [selectedBackground, setSelectedBackground] = useState('pure-white');
  
  const backgroundOptions = [
    // Neutral & White Tones
    { name: 'Pure White', color: '#ffffff', value: 'pure-white' },
    { name: 'Off White', color: '#fefefe', value: 'off-white' },
    { name: 'Cream White', color: '#fdfcf8', value: 'cream-white' },
    { name: 'Warm White', color: '#faf9f6', value: 'warm-white' },
    
    // Light Gray Tones
    { name: 'Pearl Gray', color: '#f8f9fa', value: 'pearl-gray' },
    { name: 'Dove Gray', color: '#f5f5f5', value: 'dove-gray' },
    { name: 'Silver Mist', color: '#f1f3f4', value: 'silver-mist' },
    { name: 'Cool Gray', color: '#f0f1f3', value: 'cool-gray' },
    
    // Warm Tones
    { name: 'Linen', color: '#faf0e6', value: 'linen' },
    { name: 'Alabaster', color: '#fefcf3', value: 'alabaster' },
    { name: 'Vanilla Cream', color: '#fef7ed', value: 'vanilla-cream' },
    { name: 'Parchment', color: '#f7f3e9', value: 'parchment' },
    { name: 'Champagne', color: '#f5efdb', value: 'champagne' },
    
    // Subtle Colors
    { name: 'Pale Blue', color: '#f0f8ff', value: 'pale-blue' },
    { name: 'Soft Mint', color: '#f0fff4', value: 'soft-mint' },
    { name: 'Blush Pink', color: '#fff5f5', value: 'blush-pink' },
    { name: 'Lavender Mist', color: '#f9f7ff', value: 'lavender-mist' },
    { name: 'Sage Green', color: '#f6f8f6', value: 'sage-green' },
    
    // Medium Tones
    { name: 'Warm Beige', color: '#e8dcc0', value: 'warm-beige' },
    { name: 'Stone Gray', color: '#e0e0e0', value: 'stone-gray' },
    { name: 'Mushroom', color: '#d7cfc1', value: 'mushroom' },
    { name: 'Taupe', color: '#d2b48c', value: 'taupe' },
    
    // Bold Options
    { name: 'Navy Blue', color: '#1e3a5f', value: 'navy-blue' },
    { name: 'Forest Green', color: '#2d5a3d', value: 'forest-green' },
    { name: 'Charcoal', color: '#374151', value: 'charcoal' },
    { name: 'Deep Black', color: '#000000', value: 'deep-black' },
    
    // Rich Colors
    { name: 'Burgundy', color: '#722f37', value: 'burgundy' },
    { name: 'Deep Teal', color: '#2c5f5f', value: 'deep-teal' },
    { name: 'Chocolate', color: '#5c4033', value: 'chocolate' }
  ];

  const getBackgroundColor = (bgValue: string) => {
    const option = backgroundOptions.find(opt => opt.value === bgValue);
    return option?.color || '#ffffff';
  };

  if (!artwork) return null;

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/80 z-50"
            onClick={onClose}
          />

          {/* Modal */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed inset-4 md:inset-8 lg:inset-16 z-50 overflow-auto"
          >
            <Card className="max-w-6xl mx-auto h-full flex flex-col">
              {/* Header */}
              <div className="flex items-center justify-between p-6 border-b">
                <h2 className="text-2xl font-medium">{artwork.title}</h2>
                <div className="flex items-center gap-2">
                  <motion.button
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                    onClick={onToggleFavorite}
                    className="p-2 hover:bg-muted rounded-full transition-colors"
                  >
                    <Heart 
                      className={`h-5 w-5 ${
                        isFavorite ? 'fill-red-500 text-red-500' : 'text-muted-foreground'
                      }`} 
                    />
                  </motion.button>
                  
                  <motion.button
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                    className="p-2 hover:bg-muted rounded-full transition-colors"
                  >
                    <Share2 className="h-5 w-5 text-muted-foreground" />
                  </motion.button>
                  
                  <Button variant="ghost" size="sm" onClick={onClose}>
                    <X className="h-5 w-5" />
                  </Button>
                </div>
              </div>

              {/* Content */}
              <CardContent className="flex-1 overflow-auto p-0">
                <div className="grid lg:grid-cols-2 h-full">
                  {/* Image */}
                  <motion.div
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.1 }}
                    className="relative bg-muted/20"
                  >
                    <div className="sticky top-0 p-6 h-[70vh] lg:h-full space-y-4">
                      {/* Background Color Selector */}
                      <div className="bg-white/95 backdrop-blur-sm rounded-lg p-4 shadow-sm">
                        <div className="flex items-center gap-2 mb-4">
                          <Palette className="h-4 w-4 text-muted-foreground" />
                          <span className="text-sm font-medium">Preview Background</span>
                          <span className="text-xs text-muted-foreground ml-auto">
                            {backgroundOptions.find(opt => opt.value === selectedBackground)?.name}
                          </span>
                        </div>
                        <div className="grid grid-cols-6 sm:grid-cols-8 gap-2 max-h-32 overflow-y-auto">
                          {backgroundOptions.map((option) => (
                            <button
                              key={option.value}
                              onClick={() => setSelectedBackground(option.value)}
                              className={`w-8 h-8 rounded-lg border-2 transition-all duration-200 hover:scale-105 ${
                                selectedBackground === option.value 
                                  ? 'border-primary ring-2 ring-primary/20 scale-110 shadow-md' 
                                  : 'border-border hover:border-muted-foreground hover:shadow-sm'
                              }`}
                              style={{ backgroundColor: option.color }}
                              title={option.name}
                            />
                          ))}
                        </div>
                        <div className="mt-3 text-xs text-muted-foreground">
                          Click colors to preview how your artwork looks on different walls
                        </div>
                      </div>

                      <div className="relative w-full h-full rounded-lg overflow-hidden group">
                        <div 
                          className="w-full h-full flex items-center justify-center p-8 transition-colors duration-300"
                          style={{ backgroundColor: getBackgroundColor(selectedBackground) }}
                        >
                          <ImageWithFallback
                            src={artwork.image}
                            alt={artwork.title}
                            className="max-w-full max-h-full object-contain drop-shadow-lg"
                          />
                        </div>
                        
                        {/* Image Actions */}
                        <motion.div
                          className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity"
                          initial={false}
                        >
                          <Button variant="secondary" size="sm">
                            <Download className="h-4 w-4 mr-2" />
                            View Full Size
                          </Button>
                        </motion.div>
                      </div>
                    </div>
                  </motion.div>

                  {/* Details */}
                  <motion.div
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.2 }}
                    className="p-6 space-y-6"
                  >
                    {/* Price and Actions */}
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-3xl font-medium">${artwork.price}</p>
                          <div className="flex items-center gap-2 mt-2">
                            <Badge variant={artwork.isOriginal ? 'default' : 'secondary'}>
                              {artwork.isOriginal ? 'Original' : 'Print'}
                            </Badge>
                            <Badge variant="outline">{artwork.category}</Badge>
                          </div>
                        </div>
                      </div>

                      <motion.div
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                      >
                        <Button 
                          className="w-full" 
                          size="lg" 
                          onClick={() => onAddToCart(artwork)}
                        >
                          <ShoppingCart className="h-5 w-5 mr-2" />
                          Add to Cart
                        </Button>
                      </motion.div>
                    </div>

                    <Separator />

                    {/* Description */}
                    <div>
                      <h3 className="font-medium mb-3">Description</h3>
                      <p className="text-muted-foreground leading-relaxed">
                        {artwork.description}. This piece explores the intersection of color and emotion, 
                        creating a visual dialogue that speaks to the viewer's inner experience. The careful 
                        composition and masterful technique showcase the artist's deep understanding of their medium.
                      </p>
                    </div>

                    {/* Specifications */}
                    <div>
                      <h3 className="font-medium mb-3">Specifications</h3>
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <p className="text-muted-foreground">Dimensions</p>
                          <p>{artwork.dimensions}</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Medium</p>
                          <p>{artwork.medium}</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Type</p>
                          <p>{artwork.isOriginal ? 'Original Artwork' : 'Limited Edition Print'}</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Category</p>
                          <p>{artwork.category}</p>
                        </div>
                      </div>
                    </div>

                    {/* Artist Note */}
                    <div className="bg-muted/30 p-4 rounded-lg">
                      <h4 className="font-medium mb-2">Artist's Note</h4>
                      <p className="text-sm text-muted-foreground italic">
                        "This piece was created during a period of deep reflection on the nature of beauty 
                        and its role in our daily lives. I wanted to capture not just the visual elements, 
                        but the emotional resonance that art can bring to any space."
                      </p>
                    </div>

                    {/* Care Instructions */}
                    <div>
                      <h3 className="font-medium mb-3">Care Instructions</h3>
                      <ul className="text-sm text-muted-foreground space-y-1">
                        <li>• Keep away from direct sunlight to prevent fading</li>
                        <li>• Handle with clean, dry hands</li>
                        <li>• Frame with UV-protective glass for longevity</li>
                        <li>• Store in a cool, dry environment</li>
                      </ul>
                    </div>

                    {/* Shipping Info */}
                    <div className="bg-muted/30 p-4 rounded-lg">
                      <h4 className="font-medium mb-2">Shipping & Returns</h4>
                      <div className="text-sm text-muted-foreground space-y-1">
                        <p>• Free shipping on orders over $300</p>
                        <p>• Carefully packaged with protective materials</p>
                        <p>• 30-day return policy for undamaged items</p>
                        <p>• Estimated delivery: 5-7 business days</p>
                      </div>
                    </div>
                  </motion.div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}