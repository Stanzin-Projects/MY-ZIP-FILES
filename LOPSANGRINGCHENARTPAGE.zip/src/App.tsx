import { useState, useEffect } from 'react';
import { Navigation } from './components/Navigation';
import { HeroSection } from './components/HeroSection';
import { ArtGallery, type Artwork } from './components/ArtGallery';
import { ShoppingCart, type CartItem } from './components/ShoppingCart';
import { ArtworkDetail } from './components/ArtworkDetail';
import { AboutSection } from './components/AboutSection';
import { ContactSection } from './components/ContactSection';
import { AdminPanel } from './components/AdminPanel';
import { Checkout } from './components/Checkout';
import { OrderTracking } from './components/OrderTracking';
import { type SiteContent } from './components/ContentManagement';
import { Toaster } from './components/ui/sonner';
import { Button } from './components/ui/button';
import { Settings, Key, LogOut, Package } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

export default function App() {
  // Site Content State with Offer Management
  const [siteContent, setSiteContent] = useState<SiteContent>({
    general: {
      siteName: 'ARTBYLOPSANG',
      logo: 'https://images.cdn-files-a.com/uploads/7871374/400_filter_nobg_661f5231a6a43.png',
      tagline: 'Creating meaningful art that transforms spaces and touches hearts'
    },
    hero: {
      title: 'Art that Speaks to Your Soul',
      subtitle: 'Discover unique artworks that transform spaces',
      description: 'Explore our curated collection of original paintings, limited edition prints, and commissioned artworks. Each piece is carefully crafted to bring beauty and meaning to your space.',
      ctaText: 'Explore Gallery',
      backgroundImage: 'https://images.cdn-files-a.com/uploads/7871374/2000_644d45ca0954b.png'
    },
    about: {
      title: 'About the Artist',
      subtitle: 'Creating meaningful connections through art',
      description: 'With over a decade of experience in contemporary art, I create pieces that bridge the gap between traditional techniques and modern expression. My work explores themes of nature, human emotion, and the interconnectedness of all things.',
      image: 'https://images.cdn-files-a.com/uploads/7871374/2000_644a7ebe3625f_filter_645ca89d0848f.png',
      stats: [
        { value: '100+', label: 'Artworks Created' },
        { value: '50+', label: 'Happy Collectors' },
        { value: '5+', label: 'Years Experience' },
        { value: '10+', label: 'Exhibitions' }
      ]
    },
    contact: {
      title: 'Get in Touch',
      description: 'Interested in commissioning a piece or learning more about my work? I\'d love to hear from you.',
      email: 'artist@artbylopsang.com',
      phone: '+1 (555) 123-4567',
      address: '123 Art District, Creative City, NY 10001',
      website: 'https://artbylopsang.com'
    },
    offers: {
      enabled: false,
      title: 'Special Offer',
      description: 'Limited time discount on selected artworks',
      discountPercentage: 20,
      startDate: '',
      endDate: '',
      applicableCategories: ['All'],
      minimumPurchase: 0
    }
  });

  // Art Gallery State - Expanded Collection (20+ Artworks)
  const [artworks, setArtworks] = useState<Artwork[]>([
    {
      id: '1',
      title: 'Ethereal Waves',
      price: 650,
      originalPrice: 800,
      discount: 19,
      category: 'Abstract',
      image: 'https://images.cdn-files-a.com/uploads/7871374/2000_644d45c730548.png',
      description: 'A fluid exploration of movement and color',
      dimensions: '24" x 36"',
      medium: 'Acrylic on Canvas',
      isOriginal: true
    },
    {
      id: '2',
      title: 'Urban Symphony',
      price: 450,
      category: 'Urban',
      image: 'https://images.cdn-files-a.com/uploads/7871374/2000_644d45c912fd4.png',
      description: 'Capturing the rhythm of city life',
      dimensions: '20" x 30"',
      medium: 'Mixed Media',
      isOriginal: true
    },
    {
      id: '3',
      title: 'Mountain Serenity',
      price: 350,
      originalPrice: 450,
      discount: 22,
      category: 'Landscape',
      image: 'https://images.cdn-files-a.com/uploads/7871374/2000_644d45b2b6b0b.png',
      description: 'Peaceful mountain landscape at dawn',
      dimensions: '18" x 24"',
      medium: 'Oil on Canvas',
      isOriginal: false
    },
    {
      id: '4',
      title: 'Portrait of Grace',
      price: 800,
      category: 'Portrait',
      image: 'https://images.cdn-files-a.com/uploads/7871374/2000_644d45b8d4ae7.png',
      description: 'A study in light and emotion',
      dimensions: '16" x 20"',
      medium: 'Charcoal on Paper',
      isOriginal: true
    },
    {
      id: '5',
      title: 'Color Burst',
      price: 520,
      originalPrice: 650,
      discount: 20,
      category: 'Abstract',
      image: 'https://images.cdn-files-a.com/uploads/7871374/2000_644d45c912fd4.png',
      description: 'An explosion of vibrant colors and energy',
      dimensions: '22" x 28"',
      medium: 'Acrylic on Canvas',
      isOriginal: true
    },
    {
      id: '6',
      title: 'Still Life Elegance',
      price: 380,
      category: 'Still Life',
      image: 'https://images.cdn-files-a.com/uploads/7871374/2000_644d45ca0954b.png',
      description: 'Classical still life with modern twist',
      dimensions: '16" x 20"',
      medium: 'Oil on Canvas',
      isOriginal: false
    },
    {
      id: '7',
      title: 'Abstract Flow',
      price: 420,
      category: 'Abstract',
      image: 'https://images.unsplash.com/photo-1681235014294-588fea095706?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhYnN0cmFjdCUyMHBhaW50aW5nJTIwYXJ0fGVufDF8fHx8MTc1Njc5NTc3Mnww&ixlib=rb-4.1.0&q=80&w=1080',
      description: 'Dynamic abstract composition with bold colors',
      dimensions: '20" x 24"',
      medium: 'Mixed Media',
      isOriginal: true
    },
    {
      id: '8',
      title: 'Nature\'s Canvas',
      price: 480,
      originalPrice: 600,
      discount: 20,
      category: 'Landscape',
      image: 'https://images.unsplash.com/photo-1703593693038-3a326e089c86?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsYW5kc2NhcGUlMjBwYWludGluZyUyMG5hdHVyZXxlbnwxfHx8fDE3NTY4MDEwMDd8MA&ixlib=rb-4.1.0&q=80&w=1080',
      description: 'Vibrant landscape capturing autumn colors',
      dimensions: '24" x 30"',
      medium: 'Oil on Canvas',
      isOriginal: true
    },
    {
      id: '9',
      title: 'Inner Vision',
      price: 720,
      category: 'Portrait',
      image: 'https://images.unsplash.com/photo-1701958213864-2307a737e853?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwb3J0cmFpdCUyMHBhaW50aW5nJTIwYXJ0fGVufDF8fHx8MTc1Njc0MDYxMnww&ixlib=rb-4.1.0&q=80&w=1080',
      description: 'Contemporary portrait with expressive brushstrokes',
      dimensions: '18" x 24"',
      medium: 'Acrylic on Canvas',
      isOriginal: true
    },
    {
      id: '10',
      title: 'Street Rhythm',
      price: 380,
      category: 'Urban',
      image: 'https://images.unsplash.com/photo-1652001021257-504f2ffe25ed?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx1cmJhbiUyMHN0cmVldCUyMGFydHxlbnwxfHx8fDE3NTY3MTE2ODZ8MA&ixlib=rb-4.1.0&q=80&w=1080',
      description: 'Urban street art with contemporary flair',
      dimensions: '24" x 36"',
      medium: 'Spray Paint on Canvas',
      isOriginal: false
    },
    {
      id: '11',
      title: 'Quiet Moments',
      price: 320,
      originalPrice: 400,
      discount: 20,
      category: 'Still Life',
      image: 'https://images.cdn-files-a.com/uploads/7871374/2000_644d45c730548.png',
      description: 'Serene still life with subtle lighting',
      dimensions: '16" x 20"',
      medium: 'Oil on Canvas',
      isOriginal: false
    },
    {
      id: '12',
      title: 'Modern Expression',
      price: 580,
      category: 'Contemporary',
      image: 'https://images.cdn-files-a.com/uploads/7871374/2000_644d45c730548.png',
      description: 'Contemporary piece exploring modern themes',
      dimensions: '22" x 28"',
      medium: 'Mixed Media',
      isOriginal: true
    },
    {
      id: '13',
      title: 'Minimal Beauty',
      price: 290,
      category: 'Minimalist',
      image: 'https://images.cdn-files-a.com/uploads/7871374/2000_644d45c730548.png',
      description: 'Clean minimalist composition',
      dimensions: '20" x 20"',
      medium: 'Acrylic on Canvas',
      isOriginal: true
    },
    {
      id: '14',
      title: 'Vibrant Energy',
      price: 490,
      originalPrice: 650,
      discount: 25,
      category: 'Abstract',
      image: 'https://images.cdn-files-a.com/uploads/7871374/2000_644d45c730548.png',
      description: 'Explosive colors in abstract harmony',
      dimensions: '24" x 32"',
      medium: 'Acrylic on Canvas',
      isOriginal: true
    },
    {
      id: '15',
      title: 'Forest Dreams',
      price: 410,
      category: 'Landscape',
      image: 'https://images.cdn-files-a.com/uploads/7871374/2000_644d45b2b6b0b.png',
      description: 'Mystical forest scene with ethereal lighting',
      dimensions: '20" x 26"',
      medium: 'Watercolor on Paper',
      isOriginal: false
    },
    {
      id: '16',
      title: 'City Lights',
      price: 520,
      category: 'Urban',
      image: 'https://images.cdn-files-a.com/uploads/7871374/2000_644d45c912fd4.png',
      description: 'Night cityscape with neon reflections',
      dimensions: '18" x 24"',
      medium: 'Oil on Canvas',
      isOriginal: true
    },
    {
      id: '17',
      title: 'Gentle Soul',
      price: 680,
      originalPrice: 850,
      discount: 20,
      category: 'Portrait',
      image: 'https://images.cdn-files-a.com/uploads/7871374/2000_644d45b8d4ae7.png',
      description: 'Tender portrait capturing inner peace',
      dimensions: '16" x 22"',
      medium: 'Charcoal and Pastel',
      isOriginal: true
    },
    {
      id: '18',
      title: 'Garden Path',
      price: 340,
      category: 'Still Life',
      image: 'https://images.cdn-files-a.com/uploads/7871374/2000_644d45ca0954b.png',
      description: 'Botanical still life with garden flowers',
      dimensions: '14" x 18"',
      medium: 'Watercolor',
      isOriginal: false
    },
    {
      id: '19',
      title: 'Cosmic Dance',
      price: 750,
      category: 'Abstract',
      image: 'https://images.cdn-files-a.com/uploads/7871374/2000_644d45c730548.png',
      description: 'Celestial abstract with swirling forms',
      dimensions: '30" x 40"',
      medium: 'Mixed Media on Canvas',
      isOriginal: true
    },
    {
      id: '20',
      title: 'Desert Sunset',
      price: 430,
      category: 'Landscape',
      image: 'https://images.cdn-files-a.com/uploads/7871374/2000_644d45c730548.png',
      description: 'Warm desert landscape at golden hour',
      dimensions: '22" x 30"',
      medium: 'Oil on Canvas',
      isOriginal: false
    },
    {
      id: '21',
      title: 'Reflection',
      price: 590,
      category: 'Contemporary',
      image: 'https://images.cdn-files-a.com/uploads/7871374/2000_644d45c730548.png',
      description: 'Contemplative contemporary artwork',
      dimensions: '24" x 24"',
      medium: 'Acrylic and Collage',
      isOriginal: true
    },
    {
      id: '22',
      title: 'Serenity',
      price: 380,
      originalPrice: 480,
      discount: 21,
      category: 'Minimalist',
      image: 'https://images.cdn-files-a.com/uploads/7871374/2000_644d45c730548.png',
      description: 'Peaceful minimalist composition',
      dimensions: '18" x 18"',
      medium: 'Acrylic on Canvas',
      isOriginal: false
    }
  ]);

  // Cart State
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  
  // Modal States
  const [selectedArtwork, setSelectedArtwork] = useState<Artwork | null>(null);
  const [favorites, setFavorites] = useState<Set<string>>(new Set());
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [isOrderTrackingOpen, setIsOrderTrackingOpen] = useState(false);
  
  // Admin State
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState(false);
  const [adminPassword, setAdminPassword] = useState('');
  const [showAdminLogin, setShowAdminLogin] = useState(false);

  // Orders State
  const [orders, setOrders] = useState<any[]>([]);

  // Check if offer is currently active
  const isOfferActive = () => {
    if (!siteContent.offers.enabled) return false;
    
    const now = new Date();
    const startDate = new Date(siteContent.offers.startDate);
    const endDate = new Date(siteContent.offers.endDate);
    
    return now >= startDate && now <= endDate;
  };

  // Apply offer to artwork if applicable
  const applyOfferToArtwork = (artwork: Artwork): Artwork => {
    if (!isOfferActive()) return artwork;
    
    const { offers } = siteContent;
    const isApplicable = offers.applicableCategories.includes('All') || 
                        offers.applicableCategories.includes(artwork.category);
    
    if (!isApplicable) return artwork;
    
    const discountedPrice = artwork.price * (1 - offers.discountPercentage / 100);
    
    return {
      ...artwork,
      originalPrice: artwork.originalPrice || artwork.price,
      price: Math.round(discountedPrice),
      discount: offers.discountPercentage
    };
  };

  // Apply offers to all artworks
  const artworksWithOffers = artworks.map(applyOfferToArtwork);

  // Load saved data on component mount
  useEffect(() => {
    const savedContent = localStorage.getItem('siteContent');
    if (savedContent) {
      const parsed = JSON.parse(savedContent);
      // Ensure offers section exists for backward compatibility
      if (!parsed.offers) {
        parsed.offers = {
          enabled: false,
          title: 'Special Offer',
          description: 'Limited time discount on selected artworks',
          discountPercentage: 20,
          startDate: '',
          endDate: '',
          applicableCategories: ['All'],
          minimumPurchase: 0
        };
      }
      setSiteContent(parsed);
    }

    const savedArtworks = localStorage.getItem('artworks');
    if (savedArtworks) {
      setArtworks(JSON.parse(savedArtworks));
    }

    const savedOrders = localStorage.getItem('orders');
    if (savedOrders) {
      setOrders(JSON.parse(savedOrders));
    }
  }, []);

  // Save data to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem('siteContent', JSON.stringify(siteContent));
  }, [siteContent]);

  useEffect(() => {
    localStorage.setItem('artworks', JSON.stringify(artworks));
  }, [artworks]);

  useEffect(() => {
    localStorage.setItem('orders', JSON.stringify(orders));
  }, [orders]);

  // Admin Authentication
  const handleAdminLogin = () => {
    if (adminPassword === 'admin2025') {
      setIsAdminAuthenticated(true);
      setShowAdminLogin(false);
      setIsAdminOpen(true);
      toast.success('Admin access granted');
    } else {
      toast.error('Invalid password');
    }
    setAdminPassword('');
  };

  const handleAdminLogout = () => {
    setIsAdminAuthenticated(false);
    setIsAdminOpen(false);
    toast.success('Logged out successfully');
  };

  // Content Management
  const updateSiteContent = (content: SiteContent) => {
    setSiteContent(content);
    toast.success('Site content updated successfully!');
  };

  // Artwork Management
  const updateArtwork = (updatedArtwork: Artwork) => {
    setArtworks(prev => prev.map(artwork => 
      artwork.id === updatedArtwork.id ? updatedArtwork : artwork
    ));
  };

  const addArtwork = (newArtwork: Omit<Artwork, 'id'>) => {
    const artwork: Artwork = {
      ...newArtwork,
      id: Date.now().toString()
    };
    setArtworks(prev => [...prev, artwork]);
  };

  const deleteArtwork = (id: string) => {
    setArtworks(prev => prev.filter(artwork => artwork.id !== id));
    setCartItems(prev => prev.filter(item => item.id !== id));
  };

  // Cart Functions - Use artworks with offers applied
  const addToCart = (artwork: Artwork) => {
    const artworkWithOffer = applyOfferToArtwork(artwork);
    
    setCartItems(prev => {
      const existingItem = prev.find(item => item.id === artwork.id);
      if (existingItem) {
        toast.success(`Updated ${artwork.title} quantity in cart`);
        return prev.map(item =>
          item.id === artwork.id
            ? { ...item, quantity: item.quantity + 1, price: artworkWithOffer.price }
            : item
        );
      } else {
        toast.success(`Added ${artwork.title} to cart`);
        return [...prev, { ...artworkWithOffer, quantity: 1 }];
      }
    });
  };

  const updateCartQuantity = (id: string, quantity: number) => {
    if (quantity === 0) {
      removeFromCart(id);
      return;
    }
    
    setCartItems(prev =>
      prev.map(item =>
        item.id === id ? { ...item, quantity } : item
      )
    );
  };

  const removeFromCart = (id: string) => {
    setCartItems(prev => prev.filter(item => item.id !== id));
    toast.success('Item removed from cart');
  };

  const toggleFavorite = (artworkId: string) => {
    setFavorites(prev => {
      const newFavorites = new Set(prev);
      if (newFavorites.has(artworkId)) {
        newFavorites.delete(artworkId);
        toast.success('Removed from favorites');
      } else {
        newFavorites.add(artworkId);
        toast.success('Added to favorites');
      }
      return newFavorites;
    });
  };

  // Checkout Functions
  const handleCheckout = () => {
    setIsCartOpen(false);
    setIsCheckoutOpen(true);
  };

  const handleOrderComplete = (orderData: any) => {
    setOrders(prev => [...prev, orderData]);
    setCartItems([]);
    setIsCheckoutOpen(false);
    toast.success('Order completed successfully! Check your email for confirmation.');
  };

  const cartItemCount = cartItems.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <div className="min-h-screen bg-background">
      {/* Active Offer Banner */}
      {isOfferActive() && (
        <div className="bg-primary text-primary-foreground text-center py-2 px-4 text-sm">
          🎉 {siteContent.offers.title}: {siteContent.offers.discountPercentage}% off {siteContent.offers.applicableCategories.includes('All') ? 'all artworks' : `on ${siteContent.offers.applicableCategories.join(', ')}`}!
        </div>
      )}

      {/* Admin Controls */}
      <div className="fixed top-16 right-4 z-40 flex gap-2 mt-4">
        {/* Order Tracking Button */}
        <Button
          variant="outline"
          size="sm"
          onClick={() => setIsOrderTrackingOpen(true)}
          className="opacity-80 hover:opacity-100 transition-opacity border-0"
        >
          <Package className="h-4 w-4" />
        </Button>

        {/* Admin Login/Logout */}
        {!isAdminAuthenticated ? (
          <>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowAdminLogin(!showAdminLogin)}
              className="opacity-60 hover:opacity-100 transition-opacity border-0"
            >
              <Settings className="h-4 w-4" />
            </Button>
            
            {showAdminLogin && (
              <div className="absolute top-12 right-0 bg-background rounded-lg p-4 shadow-lg w-64 z-50">
                <h3 className="font-medium mb-2">Admin Access</h3>
                <div className="space-y-2">
                  <input
                    type="password"
                    placeholder="Admin password"
                    value={adminPassword}
                    onChange={(e) => setAdminPassword(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && handleAdminLogin()}
                    className="w-full px-3 py-2 rounded text-sm bg-muted"
                  />
                  <Button size="sm" onClick={handleAdminLogin} className="w-full">
                    <Key className="h-4 w-4 mr-2" />
                    Login
                  </Button>
                  <p className="text-xs text-muted-foreground">
                    Demo password: admin2025
                  </p>
                </div>
              </div>
            )}
          </>
        ) : (
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setIsAdminOpen(true)}
              className="border-0"
            >
              <Settings className="h-4 w-4 mr-2" />
              Admin Panel
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={handleAdminLogout}
              className="text-red-600 hover:text-red-700 border-0"
            >
              <LogOut className="h-4 w-4" />
            </Button>
          </div>
        )}
      </div>

      {/* Navigation */}
      <Navigation 
        cartItemCount={cartItemCount}
        onCartClick={() => setIsCartOpen(true)}
      />

      {/* Main Content - Single Background Throughout */}
      <main className={isOfferActive() ? "pt-16" : "pt-16"}>
        <HeroSection siteContent={siteContent} />
        <ArtGallery 
          artworks={artworksWithOffers}
          onAddToCart={addToCart}
          onArtworkClick={setSelectedArtwork}
        />
        <AboutSection siteContent={siteContent} />
        <ContactSection siteContent={siteContent} />
      </main>

      {/* Shopping Cart */}
      <ShoppingCart
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cartItems={cartItems}
        onUpdateQuantity={updateCartQuantity}
        onRemoveItem={removeFromCart}
        onCheckout={handleCheckout}
      />

      {/* Checkout */}
      <Checkout
        isOpen={isCheckoutOpen}
        onClose={() => setIsCheckoutOpen(false)}
        cartItems={cartItems}
        onOrderComplete={handleOrderComplete}
      />

      {/* Order Tracking */}
      <OrderTracking
        isOpen={isOrderTrackingOpen}
        onClose={() => setIsOrderTrackingOpen(false)}
      />

      {/* Admin Panel */}
      {isAdminAuthenticated && (
        <AdminPanel
          isOpen={isAdminOpen}
          onClose={() => setIsAdminOpen(false)}
          artworks={artworks}
          onUpdateArtwork={updateArtwork}
          onAddArtwork={addArtwork}
          onDeleteArtwork={deleteArtwork}
          onLogout={handleAdminLogout}
          siteContent={siteContent}
          onUpdateSiteContent={updateSiteContent}
        />
      )}

      {/* Artwork Detail Modal */}
      <ArtworkDetail
        artwork={selectedArtwork ? applyOfferToArtwork(selectedArtwork) : null}
        isOpen={!!selectedArtwork}
        onClose={() => setSelectedArtwork(null)}
        onAddToCart={addToCart}
        isFavorite={selectedArtwork ? favorites.has(selectedArtwork.id) : false}
        onToggleFavorite={() => {
          if (selectedArtwork) {
            toggleFavorite(selectedArtwork.id);
          }
        }}
      />

      {/* Toast Notifications */}
      <Toaster position="bottom-right" />

      {/* Footer - No Border */}
      <footer className="py-12 lg:py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="sm:col-span-2 lg:col-span-1">
              <h3 className="font-medium mb-4">{siteContent.general.siteName}</h3>
              <p className="text-muted-foreground text-sm max-w-md">
                {siteContent.general.tagline}
              </p>
            </div>
            
            <div>
              <h4 className="font-medium mb-4">Quick Links</h4>
              <div className="space-y-2 text-sm">
                <a href="#gallery" className="block text-muted-foreground hover:text-foreground transition-colors">
                  Gallery
                </a>
                <a href="#about" className="block text-muted-foreground hover:text-foreground transition-colors">
                  About
                </a>
                <a href="#contact" className="block text-muted-foreground hover:text-foreground transition-colors">
                  Contact
                </a>
                <button
                  onClick={() => setIsOrderTrackingOpen(true)}
                  className="block text-muted-foreground hover:text-foreground transition-colors text-left"
                >
                  Track Order
                </button>
              </div>
            </div>
            
            <div>
              <h4 className="font-medium mb-4">Policies</h4>
              <div className="space-y-2 text-sm">
                <a href="#" className="block text-muted-foreground hover:text-foreground transition-colors">
                  Shipping & Returns
                </a>
                <a href="#" className="block text-muted-foreground hover:text-foreground transition-colors">
                  Privacy Policy
                </a>
                <a href="#" className="block text-muted-foreground hover:text-foreground transition-colors">
                  Terms of Service
                </a>
                <a href="#" className="block text-muted-foreground hover:text-foreground transition-colors">
                  Care Instructions
                </a>
              </div>
            </div>
          </div>
          
          <div className="mt-8 pt-8 text-center text-sm text-muted-foreground">
            <p>&copy; 2025 {siteContent.general.siteName}. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}